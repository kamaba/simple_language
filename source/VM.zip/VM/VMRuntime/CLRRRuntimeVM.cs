
using SimpleLanguage.Logging;

namespace SimpleLanguage.VM.Runtime
{
    public class CLRVM
    {
        public static bool isPrint { get; set; } = false;
        public static RuntimeVM currentCLRRuntime = null;
        public static RuntimeVM topCLRRuntime = null;

        // Fast lookup list for global ids. It only stores slot mapping metadata,
        // actual values are always stored on RuntimeType static fields.
        // Per-module global init entries: each module's static-variable init
        // instructions are stored with the owning moduleUUID so LoadConstString
        // and other module-scoped lookups resolve correctly during init.
        private struct ModuleGlobalInitEntry
        {
            public string moduleUUID;
            public string moduleName;
            public List<Instruction> instructions;
        }
        private static List<ModuleGlobalInitEntry> m_ModuleGlobalInitList = new List<ModuleGlobalInitEntry>();
        private static Dictionary<uint, RuntimeVariable> m_GlobalVariableDict = new Dictionary<uint, RuntimeVariable>();
        private static bool m_IsGlobalInitApplied = false;
        private static bool m_IsGlobalInitApplying = false;
        public static Stack<RuntimeVM> clrRuntimeStack => m_ClrRuntimeStack;

        private static Stack<RuntimeVM> m_ClrRuntimeStack = new Stack<RuntimeVM>();
        public CLRVM()
        {

        }
        public static void Init()
        {
        }
        public static RuntimeVM GetCLRRuntimeById( string id )
        {
            foreach( var v in m_ClrRuntimeStack )
            {
                if( v.id == id )
                {
                    return v;
                }
            }
            return null;
        }
        public static void RunIRNewMethod(string id, RuntimeType rt, List<Instruction> irlist, bool isGetStackValue, string moduleUUID = "", string moduleName = "" )
        {
            try
            {
                topCLRRuntime = m_ClrRuntimeStack.Count > 0  ? m_ClrRuntimeStack.Peek() : null;
                Log.AddVM(LID.ShowMessageInfo, $"RunIRNewMethod id={id} rt={rt} irlist.count={irlist?.Count}");
                RuntimeVM clrRuntime = new RuntimeVM(id, rt, new List<RuntimeType>(), irlist);
                clrRuntime.SetCurrentModuleUUID(moduleUUID);
                clrRuntime.SetCurrentModuleName(moduleName);
                m_ClrRuntimeStack.Push(clrRuntime);
                if(isGetStackValue )
                    clrRuntime.SetNewObject();
                else
                {
                    clrRuntime.SetCurrentRuntimeType(rt);
                }
                clrRuntime.Run(true);
                clrRuntime.ClearNewObject();
                PopCLRRuntime();
                topCLRRuntime = m_ClrRuntimeStack.Count > 0 ? m_ClrRuntimeStack.Peek() : null;
            }
            catch (Exception ex)
            {
                Log.AddVM(LID.ShowMessageError, $"RunIRNewMethod id={id} rt={rt} irlist.count={irlist?.Count} exception={ex}");
            }
        }
        public static void RunIRMethodByRuntimeType(RuntimeType rt, List<RuntimeType> rtList, RuntimeMethod method, bool isDisCountStackCount = true, bool tryCatch = false)
        {
            topCLRRuntime = m_ClrRuntimeStack.Peek();
            RuntimeVM clrRuntime = null;

            var getrt = GetCLRRuntimeById(method.id);
            //if( getrt != null )
            //{
            //    return getrt;
            //}
            //else
            {
                clrRuntime = new RuntimeVM(rt, rtList, method);
                // Pass caller's TryStack to callee so ExecuteThrow can check
                // whether an upstream catch handler exists.
                if (tryCatch)
                {
                    clrRuntime.SetParentTryStack(topCLRRuntime.tryStack);
                }
                m_ClrRuntimeStack.Push(clrRuntime);
            }
            clrRuntime.Run(isDisCountStackCount);
            PopCLRRuntime();
            topCLRRuntime = m_ClrRuntimeStack.Count > 0 ? m_ClrRuntimeStack.Peek() : null;
            // Propagate uncaught VM exception from callee to caller
            if (clrRuntime.hasPendingException && topCLRRuntime != null)
            {
                if (tryCatch)
                {
                    // try call: caller's m_TryStack has a catch handler - dispatch to it
                    topCLRRuntime.PropagateException(clrRuntime.pendingException);
                }
                else
                {
                    // non-try call: skip caller's catch handlers, propagate to outer scope
                    topCLRRuntime.SetPendingException(clrRuntime.pendingException);
                }
                // Do NOT push return values when an exception was thrown -
                // the callee has no valid return value, and pushing a null
                // would corrupt the caller's stack (overwriting the exception).
            }
            else
            {
                var topt2 = m_ClrRuntimeStack.Peek();
                topt2.AddReturnObjectArray(clrRuntime.returnRuntimeObjectArray);
            }
            //if (!clrRuntime.isPersistent)
            {
            }
        }
        public static void PushCLRRuntime(RuntimeVM clrRuntime )
        {
            m_ClrRuntimeStack.Push(clrRuntime);
        }
        public static RuntimeVM PopCLRRuntime()
        {
            return m_ClrRuntimeStack.Pop();
        }
        public static void LoadGlobalVariableMapping()
        {
            if (m_IsGlobalInitApplied || m_IsGlobalInitApplying)
            {
                return;
            }
            if (m_ModuleGlobalInitList == null || m_ModuleGlobalInitList.Count == 0)
            {
                m_IsGlobalInitApplied = true;
                return;
            }
            m_IsGlobalInitApplying = true;
            // Run each module's init instructions with the correct module UUID
            // so that module-scoped lookups (e.g. LoadConstString) resolve properly.
            for (int i = 0; i < m_ModuleGlobalInitList.Count; i++)
            {
                var entry = m_ModuleGlobalInitList[i];
                if (entry.instructions == null || entry.instructions.Count == 0) continue;
                RunIRNewMethod("__global_init__", null, new List<Instruction>(entry.instructions), false, entry.moduleUUID, entry.moduleName);
            }
            m_IsGlobalInitApplied = true;
            m_IsGlobalInitApplying = false;
        }
        public static void ResetGlobalVariableMapping()
        {
            m_GlobalVariableDict.Clear();
            m_ModuleGlobalInitList.Clear();
            m_IsGlobalInitApplied = false;
            m_IsGlobalInitApplying = false;
        }
        public static void RegisterGlobalVariable(uint id, RuntimeVariable rv )
        {
            if (m_GlobalVariableDict.ContainsKey(id))
            {
                return;
            }
            m_GlobalVariableDict[id] = rv;  
        }

        /// <summary>
        /// Adds a module's global static-variable init instructions with the owning
        /// moduleUUID and moduleName. Each module's instructions are executed separately
        /// with the correct module context during <see cref="LoadGlobalVariableMapping"/>.
        /// </summary>
        public static void AddModuleGlobalInitInstructions(string moduleUUID, string moduleName, List<Instruction> instructionList)
        {
            m_ModuleGlobalInitList.Add(new ModuleGlobalInitEntry
            {
                moduleUUID = moduleUUID ?? string.Empty,
                moduleName = moduleName ?? string.Empty,
                instructions = instructionList ?? new List<Instruction>(),
            });
            m_IsGlobalInitApplied = false;
        }
        public static void StoreGlobalVariable( uint id, ref RuntimeValue savl )
        {
            if (m_GlobalVariableDict.ContainsKey(id))
            {
                var slot = m_GlobalVariableDict[id];
                var rt = RuntimeTypeManager.GetRuntimeTypeByDefTypeAndAdd(slot.runtimeDefType);
                if (rt != null)
                {
                    rt.SetStaticMemberVariableSValue((int)id, ref savl);
                }
                else
                {
                    Log.AddRuntimeLog(LID.ShowMessageAssert, $"global is null globalId={id}");
                }
            }
            else
            {
                Log.AddRuntimeLog(LID.ShowMessageAssert, $"global is nullglobalId={id}");
            }

        }
        public static void LoadGlobalVariable( uint id, ref RuntimeValue sval )
        {
            if (m_GlobalVariableDict.ContainsKey(id))
            {
                var slot = m_GlobalVariableDict[id];
                var rt = RuntimeTypeManager.GetRuntimeTypeByDefTypeAndAdd(slot.runtimeDefType);
                if (rt != null)
                {
                    rt.GetStaticMemberVariableSValue((int)id, ref sval);
                }
                else
                {
                    sval.SetNull();
                    Log.AddRuntimeLog(LID.ShowMessageAssert, $"global is null globalId={id} ");
                }
            }
            else
            {
                Log.AddRuntimeLog(LID.ShowMessageAssert, $"global is nullglobalId={id} ");
            }
        }
    }
}
