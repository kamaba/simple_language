//****************************************************************************
//  File:      RuntimeValue.cs
// ------------------------------------------------
//  Copyright (c) kamaba233@gmail.com
//  DateTime: 2022/11/22 12:00:00
//  Description: 
//****************************************************************************

using SimpleLanguage.Logging;
using SimpleLanguage.VM.Runtime;
using System.Diagnostics;
using System.Globalization;
using System.Text;
namespace SimpleLanguage.VM
{
    public struct RuntimeValue
    {
        public EVMType eType;
        private NumericUnion nv;
        public string? stringValue;
        public SObject? sobject;
        public bool isNull;

        public byte uint8Value { get => nv.u8; set => nv.u8 = value; }
        public sbyte int8Value { get => nv.i8; set => nv.i8 = value; }
        //public char charValue;
        public short int16Value { get => nv.i16; set => nv.i16 = value; }
        public ushort uint16Value { get => nv.u16; set => nv.u16 = value; }
        public int int32Value { get => nv.i32; set => nv.i32 = value; }
        public uint uint32Value { get => nv.u32; set => nv.u32 = value; }
        public long int64Value { get => nv.i64; set => nv.i64 = value; }
        public ulong uint64Value { get => nv.u64; set => nv.u64 = value; }
        public float float32Value { get => nv.f32; set => nv.f32 = value; }
        public double float64Value { get => nv.f64; set => nv.f64 = value; }
        public object? ToClrObject(Type targetType)
        {
            if (isNull) return null;

            // NativeBridge/BridgeObject 鍙傛暟钀藉湴锛歏M 渚у皢 BridgeObject 瀹炰緥瑙ｆ瀽鎴愮洰�?CLR 绫诲瀷銆?
            // BridgeObject �?Front 閲岄€氳�?_init_(string type) 浣滀负鈥滃弬鏁版弿杩扮鈥濅紶鍏ワ紝
            // �?VM 杩愯鏃堕€氬父浼氳鍐欏叆鏌愪釜鍙鎴愬憳鍙橀噺锛堝父瑙佷�?`type`锛夛紝鍥犳杩欓噷鍋氬绉拌浆鎹€?
            if (sobject != null && IsBridgeObjectRuntime(sobject.runtimeClass))
            {
                var co = sobject;
                if (TryExtractBridgeObjectPayload(co, out var payloadObj))
                {
                    if (payloadObj == null) return null;
                    if (targetType == typeof(object)) return payloadObj;
                    if (targetType == typeof(string))
                        return payloadObj is string s ? s : payloadObj.ToString();

                    if (targetType.IsInstanceOfType(payloadObj)) return payloadObj;

                    // BridgeObject 閲岀殑鍊煎父甯告槸瀛楃涓插舰寮忥紙渚嬪 BridgeObject(123) 浼氳惤涓?"123"�?
                    if (payloadObj is string payloadStr)
                    {
                        if (targetType == typeof(int) && int.TryParse(payloadStr, NumberStyles.Integer, CultureInfo.InvariantCulture, out var i))
                            return i;
                        if (targetType == typeof(long) && long.TryParse(payloadStr, NumberStyles.Integer, CultureInfo.InvariantCulture, out var l))
                            return l;
                        if (targetType == typeof(float) && float.TryParse(payloadStr, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out var f))
                            return f;
                        if (targetType == typeof(double) && double.TryParse(payloadStr, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out var d))
                            return d;
                        if (targetType == typeof(bool))
                        {
                            if (bool.TryParse(payloadStr, out var b)) return b;
                            if (int.TryParse(payloadStr, NumberStyles.Integer, CultureInfo.InvariantCulture, out var bi)) return bi != 0;
                        }
                    }

                    // 鏈€鍚庡厹搴曪細灏濊瘯绯荤粺杞崲锛堝閮ㄥ垎鏁板€?鏋氫妇鍙兘鏈夋晥锛?
                    if (targetType.IsEnum)
                    {
                        try { return Enum.ToObject(targetType, payloadObj); } catch { /* ignore */ }
                    }
                    try { return Convert.ChangeType(payloadObj, targetType); } catch { /* ignore */ }
                }
            }

            if (targetType == typeof(object)) return GetValueObject();
            if (targetType == typeof(string)) return eType == EVMType.String ? stringValue : GetValueObject()?.ToString();
            if (targetType == typeof(bool)) return eType == EVMType.Boolean ? (uint8Value == 1) : Convert.ToBoolean(GetValueObject());
            if (targetType == typeof(int)) return eType == EVMType.Int32 ? int32Value : Convert.ToInt32(GetValueObject());
            if (targetType == typeof(long)) return eType == EVMType.Int64 ? int64Value : Convert.ToInt64(GetValueObject());
            if (targetType == typeof(float)) return eType == EVMType.Float32 ? float32Value : Convert.ToSingle(GetValueObject());
            if (targetType == typeof(double)) return eType == EVMType.Float64 ? float64Value : Convert.ToDouble(GetValueObject());
            return Convert.ChangeType(GetValueObject(), targetType);
        }

        private static bool IsBridgeObjectRuntime(RuntimeClass? runtimeClass)
        {
            if (runtimeClass == null) return false;
            var n = runtimeClass.name ?? string.Empty;
            return n.EndsWith("BridgeObject", StringComparison.Ordinal) || n.Contains(".BridgeObject", StringComparison.Ordinal);
        }

        private static bool TryExtractBridgeObjectPayload(SObject co, out object? payloadObj)
        {
            payloadObj = null;
            var rc = co.runtimeClass;
            if (rc == null) return false;

            var vars = rc.nonStaticIRMetaVariableList;
            if (vars == null || vars.Count == 0) return false;

            // _init_ 鍙傛暟鍚嶆槸 `type`锛屽洜姝や紭鍏堣杩欎釜鎴愬憳鍙橀噺锛涘鏋滀笉瀛樺湪锛屽垯閫€鍖栦负璇诲彇绗竴涓垚鍛樺彉閲忋€?
            int index = -1;
            for (int i = 0; i < vars.Count; i++)
            {
                var vn = vars[i]?.name ?? string.Empty;
                if (string.Equals(vn, "type", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(vn, "_type", StringComparison.OrdinalIgnoreCase))
                {
                    index = i;
                    break;
                }
            }
            if (index < 0) index = 0;

            var sv = default(RuntimeValue);
            co.GetMemberVariableSValue(index, ref sv);
            payloadObj = sv.GetValueObject();
            return true;
        }

        public static RuntimeValue FromClrObject(object? o)
        {
            var v = default(RuntimeValue);
            if (o == null)
            {
                v.SetNull();
                return v;
            }

            switch (o)
            {
                case bool b: v.SetBoolValue(b); break;
                case byte b8: v.SetUInt8Value(b8); break;
                case sbyte sb8: v.SetInt8Value(sb8); break;
                case short i16: v.SetInt16Value(i16); break;
                case ushort u16: v.SetUInt16Value(u16); break;
                case int i32: v.SetInt32Value(i32); break;
                case uint u32: v.SetUInt32Value(u32); break;
                case long i64: v.SetInt64Value(i64); break;
                case ulong u64: v.SetUInt64Value(u64); break;
                case float f: v.SetFloatValue(f); break;
                case double d: v.SetDoubleValue(d); break;
                case string s: v.SetStringValue(s); break;
                default: v.SetNull(); break;
            }
            return v;
        }
        public void SetNullValueType()
        {
            eType = EVMType.Null;
            SetNull();
        }
        public void SetNull()
        {
            isNull = true;
            int8Value = 0;
            uint8Value = 0;
            int16Value = 0;
            uint16Value = 0;
            int32Value = 0;
            uint32Value = 0;
            int64Value = 0;
            uint64Value = 0;
            float32Value = 0;
            float64Value = 0;
            stringValue = null;
            sobject = null;
        }
        public void SetBoolValue(bool val)
        {
            isNull = false;
            eType = EVMType.Boolean;
            var b = val ? (byte)1 : (byte)0;
            uint8Value = b;
            int8Value = (sbyte)b;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const Boolean: " + val);
#endif
        }
        public void SetUInt8Value(byte val)
        {
            eType = EVMType.UInt8;
            uint8Value = val;
            isNull = false;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const UInt8: " + val);
#endif
        }
        public void SetInt8Value(sbyte val)
        {
            eType = EVMType.Int8;
            int8Value = val;
            isNull = false;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const Int16: " + val);
#endif
        }
        //public void SetCharValue(char val)
        //{
        //    eType = EVMType.Char;
        //    charValue = val;
        //}
        public void SetInt16Value(Int16 val)
        {
            eType = EVMType.Int16;
            int16Value = val;
            isNull = false;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const UInt16: " + val);
#endif
        }
        public void SetUInt16Value(UInt16 val)
        {
            eType = EVMType.UInt16;
            uint16Value = val;
            isNull = false;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const Int8: " + val);
#endif
        }
        public void SetInt32Value(Int32 val)
        {
            eType = EVMType.Int32;
            int32Value = val;
            isNull = false;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const Int32: " + val);
#endif
        }
        public void SetUInt32Value(UInt32 val)
        {
            eType = EVMType.UInt32;
            uint32Value = val;
            isNull = false;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const UInt32: " + val);
#endif
        }
        public void SetInt64Value(Int64 val)
        {
            eType = EVMType.Int64;
            int64Value = val;
            isNull = false;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const Int64: " + val);
#endif
        }
        public void SetUInt64Value(UInt64 val)
        {
            eType = EVMType.UInt64;
            uint64Value = val;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const UInt64: " + val);
#endif
        }
        public void SetFloatValue(Single val)
        {
            eType = EVMType.Float32;
            float32Value = val;
            isNull = false;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const Float32: " + val);
#endif
        }
        public void SetDoubleValue(Double val)
        {
            eType = EVMType.Float64;
            float64Value = val;
            isNull = false;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const Float64: " + val);
#endif
        }
        public void SetStringValue(string val)
        {
            eType = EVMType.String;
            stringValue = val;
            isNull = false;

            //if (sobject is StringObject strObj)
            //{
            //    strObj.SetValue(val);
            //}
            //else
            //{
            //    var strRef = new StringObject(val);
            //    ObjectManager.RegisterObject(strRef);
            //    sobject = strRef;
            //}
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const SetStringValue: " + val);
#endif
        }
        // helper conversions used by ComputeSVAlue
        public bool IsUnsignedType(EVMType t)
        {
            return t == EVMType.UInt16 || t == EVMType.UInt32 || t == EVMType.UInt64;
        }
        public double ConvertToDoubleFromIntTypes()
        {
            switch (eType)
            {
                case EVMType.UInt8: return uint8Value;
                case EVMType.Int8: return int8Value;
                case EVMType.Int16: return int16Value;
                case EVMType.UInt16: return uint16Value;
                case EVMType.Int32: return int32Value;
                case EVMType.UInt32: return uint32Value;
                case EVMType.Int64: return int64Value;
                case EVMType.UInt64: return (double)uint64Value;
            }
            return 0.0;
        }
        public void AssignULongToType(ulong v)
        {
            switch (eType)
            {
                case EVMType.UInt64: uint64Value = v; break;
                case EVMType.Int64: int64Value = (long)v; break;
                case EVMType.UInt32: uint32Value = (uint)v; break;
                case EVMType.Int32: int32Value = (int)v; break;
                case EVMType.UInt16: uint16Value = (ushort)v; break;
                case EVMType.Int16: int16Value = (short)v; break;
                case EVMType.UInt8: uint8Value = (byte)v; break;
                case EVMType.Int8: int8Value = (sbyte)v; break;
                default: break;
            }
        }
        public void AssignLongToType(long v)
        {
            switch (eType)
            {
                case EVMType.Int64: int64Value = v; break;
                case EVMType.UInt64: uint64Value = (ulong)v; break;
                case EVMType.Int32: int32Value = (int)v; break;
                case EVMType.UInt32: uint32Value = (uint)v; break;
                case EVMType.Int16: int16Value = (short)v; break;
                case EVMType.UInt16: uint16Value = (ushort)v; break;
                case EVMType.UInt8: uint8Value = (byte)v; break;
                case EVMType.Int8: int8Value = (sbyte)v; break;
                default: break;
            }
        }
        public void SetStringValueByStrinbObject( StringObject so )
        {
            eType = EVMType.String;
            stringValue = so.value;
            isNull = false;
            sobject = so;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "Load Const SetStringValueByStrinbObject: " + so.value );
#endif
        }
        public void SetArrayObject( ArrayObject ao )
        {
            eType = EVMType.Array;
            sobject = ao;
            isNull = false;
#if DEBUG
            Log.AddRuntimeLog(LID.ShowMessageInfo, "RuntimeValue.SetArrayValue" + ao );
#endif
        }
        public void SetTypeObject( TypeObject to )
        {
            eType = EVMType.Type;
            sobject = to;
            isNull = false;
            Log.AddRuntimeLog(LID.ShowMessageInfo, "RuntimeValue.SetTypeValue" + to);
        }
        public void SetValue(SObject val)
        {
            eType = val.eType;
            SetTypeValue(eType, val.value);
        }
        public void SetTypeValue(EVMType etype, object tobj)
        {
            switch (eType)
            {
                case EVMType.UInt8:
                    {
                        uint8Value = (byte)(tobj);
                    }
                    break;
                case EVMType.Boolean:
                    {
                        var b = (byte)tobj == 1 ? (byte)1 : (byte)0;
                        uint8Value = b;
                        int8Value = (sbyte)b;
                    }
                    break;
                case EVMType.Int8:
                    {
                        int8Value = (sbyte)(tobj);
                    }
                    break;
                //case EVMType.Char:
                //    {
                //        charValue = (char)(tobj);
                //    }
                //    break;
                case EVMType.Int16:
                    {
                        int16Value = (short)(tobj);
                    }
                    break;
                case EVMType.UInt16:
                    {
                        uint16Value = (ushort)(tobj);
                    }
                    break;
                case EVMType.Int32:
                    {
                        int32Value = (int)(tobj);
                    }
                    break;
                case EVMType.UInt32:
                    {
                        uint32Value = (uint)(tobj);
                    }
                    break;
                case EVMType.Int64:
                    {
                        int64Value = (long)(tobj);
                    }
                    break;
                case EVMType.UInt64:
                    {
                        uint64Value = (ulong)(tobj);
                    }
                    break;
                case EVMType.Float32:
                    {
                        float32Value = (float)(tobj);
                    }
                    break;
                case EVMType.Float64:
                    {
                        float64Value = (double)(tobj);
                    }
                    break;
                case EVMType.String:
                    {
                        stringValue = tobj as String;
                        isNull = stringValue == null;
                        if (!isNull)
                        {
                            if (sobject is StringObject strObj)
                            {
                                strObj.SetValue(stringValue);
                            }
                            else
                            {
                                var strRef = new StringObject(stringValue);
                                ObjectManager.RegisterObject(strRef);
                                sobject = strRef;
                            }
                        }
                        else
                        {
                            sobject = null;
                        }
                    }
                    break;
                case EVMType.Array:
                    {
                        sobject = tobj as ArrayObject;
                        isNull = sobject == null;
                    }
                    break;
                case EVMType.Type:
                    {
                        sobject = tobj as TypeObject;
                        isNull = sobject == null;
                    }
                    break;
                case EVMType.Object:
                    {
                        sobject = tobj as SObject;
                        isNull = sobject == null;
                    }
                    break;
                case EVMType.Class:
                    {
                        sobject = tobj as SObject;
                        isNull = sobject == null;
                    }
                    break;
                default:
                    {
                        Log.AddRuntimeLog(LID.RuntimeVMNotFoundHandleEVMType, "SetTypeValue", eType.ToString());
                    }
                    break;
            }
        }
        public void SetRawSObject( SObject val )
        {
            if (val == null)
            {
                isNull = true;
                return;
            }
            isNull = false;
            eType = val.eType;
            sobject = val;
#if DEBUG
            Log.AddVM(LID.ShowMessageInfo, "SetRawSObject: " + sobject?.hashCode );
#endif
        }
        public void SetValueBySObject(SObject val)
        {
            if (val == null)
            {
                isNull = true;
                return;
            }
            isNull = val == null;
            if (isNull)
            {
                return;
            }
            isNull = false;
            switch (val.eType)
            {
                case EVMType.Boolean:
                    {
                        eType = EVMType.Boolean;
                        uint8Value = val.m_Numeric.u8 != 0 ? (byte)1 : (byte)0;
                    }
                    break;
                case EVMType.UInt8:
                    {
                        eType = EVMType.UInt8;
                        uint8Value = val.m_Numeric.u8;
                    }
                    break;
                case EVMType.Int8:
                    {
                        eType = EVMType.Int8;
                        int8Value = val.m_Numeric.i8;
                    }
                    break;
                case EVMType.Int16:
                    {
                        eType = EVMType.Int16;
                        int16Value = val.m_Numeric.i16;
                    }
                    break;
                case EVMType.UInt16:
                    {
                        eType = EVMType.UInt16;
                        uint16Value = val.m_Numeric.u16;
                    }
                    break;
                case EVMType.Int32:
                    {
                        eType = EVMType.Int32;
                        int32Value = val.m_Numeric.i32;
                    }
                    break;
                case EVMType.UInt32:
                    {
                        eType = EVMType.UInt32;
                        uint32Value = val.m_Numeric.u32;
                    }
                    break;
                case EVMType.Int64:
                    {
                        eType = EVMType.Int64;
                        int64Value = val.m_Numeric.i64;
                    }
                    break;
                case EVMType.UInt64:
                    {
                        eType = EVMType.UInt64;
                        uint64Value = val.m_Numeric.u64;
                    }
                    break;
                case EVMType.Float32:
                    {
                        eType = EVMType.Float32;
                        float32Value = val.m_Numeric.f32;
                    }
                    break;
                case EVMType.Float64:
                case EVMType.Num:
                    {
                        eType = EVMType.Float64;
                        float64Value = val.m_Numeric.f64;
                    }
                    break;
                case EVMType.String:
                    {
                        eType = EVMType.String;
                        if (val is StringObject stringobj)
                        {
                            stringValue = stringobj.value;
                            sobject = stringobj;
                        }
                        else
                        {
                            stringValue = val.value?.ToString() ?? string.Empty;
                            sobject = val;
                        }
                    }
                    break;
                case EVMType.Array:
                    {
                        eType = EVMType.Array;
                        sobject = val;
                    }
                    break;
                case EVMType.Object:
                    {
                        eType = EVMType.Object;
                        sobject = val;
                    }
                    break;
                case EVMType.Class:
                    {
                        eType = EVMType.Class;
                        sobject = val;
                    }
                    break;
                case EVMType.Type:
                    {
                        eType = EVMType.Type;
                        sobject = val;
                    }
                    break;
                default:
                    {
                        SetRawSObject(val.value as SObject);
                    }
                    break;
            }
        }
        public SObject? GetReferenceSObject(bool createStringRef = true)
        {
            if (isNull)
                return null;

            switch (eType)
            {
                case EVMType.String:
                    {
                        if (sobject is StringObject strObj)
                        {
                            if (strObj.value != stringValue)
                                strObj.SetValue(stringValue ?? string.Empty);
                            return strObj;
                        }
                        if (!createStringRef)
                            return null;
                        var strRef = new StringObject(stringValue ?? string.Empty);
                        ObjectManager.RegisterObject(strRef);
                        sobject = strRef;
                        return strRef;
                    }
                case EVMType.Array:
                case EVMType.Object:
                case EVMType.Class:
                case EVMType.Type:
                case EVMType.Member:
                    return sobject;
                case EVMType.UInt8:
                    {
                        var num = new SObject(EVMType.UInt8);
                        num.m_Numeric.u8 = uint8Value;
                        return num;
                    }
                case EVMType.Boolean:
                    {
                        var sobj = new SObject(EVMType.Boolean);
                        sobj.m_Numeric.u8 = uint8Value;
                        return sobj;
                    }
                case EVMType.Int8:
                    {
                        var num = new SObject(EVMType.Int8);
                        num.m_Numeric.i8 = int8Value;
                        return num;
                    }
                case EVMType.Int16:
                    {
                        var num = new SObject(EVMType.Int16);
                        num.m_Numeric.i16 = int16Value;
                        return num;
                    }
                case EVMType.UInt16:
                    {
                        var num = new SObject(EVMType.UInt16);
                        num.m_Numeric.u16 = uint16Value;
                        return num;
                    }
                case EVMType.Int32:
                    {
                        var num = new SObject(EVMType.Int32);
                        num.m_Numeric.i32 = int32Value;
                        return num;
                    }
                case EVMType.UInt32:
                    {
                        var num = new SObject(EVMType.UInt32);
                        num.m_Numeric.u32 = uint32Value;
                        return num;
                    }
                case EVMType.Int64:
                    {
                        var num = new SObject(EVMType.Int64);
                        num.m_Numeric.i64 = int64Value;
                        return num;
                    }
                case EVMType.UInt64:
                    {
                        var num = new SObject(EVMType.UInt64);
                        num.m_Numeric.u64 = uint64Value;
                        return num;
                    }
                case EVMType.Float32:
                    {
                        var num = new SObject(EVMType.Float32);
                        num.m_Numeric.f32 = float32Value;
                        return num;
                    }
                case EVMType.Float64:
                case EVMType.Num:
                    {
                        var num = new SObject(EVMType.Float64);
                        num.m_Numeric.f64 = float64Value;
                        return num;
                    }
                default:
                    return null;
            }
        }
        public void TryCoerceScalarForAssignment(EVMType targetEvm)
        {
            if (isNull) return;
            if (eType == targetEvm) return;
            if (!IsScalarOrNumSlotEvm(targetEvm)) return;
            if (!IsScalarOrNumSlotEvm(eType) && eType != EVMType.Boolean) return;
            try
            {
                RuntimeValueMethod.ConvertByEType( ref this, targetEvm);
            }
            catch (OverflowException)
            {
                Log.AddRuntimeLog(LID.ShowMessageWarning,
                    $"数值赋值发生溢出，保持原�? source={eType}, target={targetEvm}, value={GetValueObject()}");
            }
            catch
            {
                // 保持原值，由后续分支决定失败表�?
            }
        }

        private static bool IsScalarOrNumSlotEvm(EVMType t)
        {
            return t is >= EVMType.Boolean and <= EVMType.Num;
        }

        private static bool IsValueLikeEvm(EVMType t)
        {
            return t == EVMType.Boolean
                || t == EVMType.UInt8
                || t == EVMType.Int8
                || t == EVMType.Int16
                || t == EVMType.UInt16
                || t == EVMType.Int32
                || t == EVMType.UInt32
                || t == EVMType.Int64
                || t == EVMType.UInt64
                || t == EVMType.Float32
                || t == EVMType.Float64
                || t == EVMType.Num;
        }

        private static bool TryUnboxObjectLikeScalar(ref RuntimeValue source, out RuntimeValue unboxed)
        {
            unboxed = source;
            if (source.isNull || source.sobject == null)
                return false;
            if (source.eType != EVMType.Object && source.eType != EVMType.Class)
                return false;

            var temp = default(RuntimeValue);
            temp.SetValueBySObject(source.sobject);
            if (temp.isNull)
                return false;

            // Keep true reference-like values untouched; only unbox scalar wrappers.
            if (temp.eType == EVMType.Object
                || temp.eType == EVMType.Class
                || temp.eType == EVMType.Array
                || temp.eType == EVMType.Type
                || temp.eType == EVMType.Member)
                return false;

            unboxed = temp;
            return true;
        }

        public bool TryNormalizeObjectScalarInPlace()
        {
            var self = this;
            if (TryUnboxObjectLikeScalar(ref self, out var unboxed))
            {
                this = unboxed;
                return true;
            }
            return false;
        }

        public void ConvertValueByTargetTypeAndObject( EVMType etype )
        {
            // 统一值类型路径：Object/Class 中若封装�?Int8Object/UInt8Object/Int16Object/... 等，
            // 先解包，再按 ConvertByEType 执行升阶/降阶与溢出处理�?
            if (IsValueLikeEvm(etype))
            {
                TryNormalizeObjectScalarInPlace();
                if (!isNull && IsValueLikeEvm(eType))
                {
                    if (eType != etype)
                    {
                        try
                        {
                            RuntimeValueMethod.ConvertByEType(ref this, etype);
                        }
                        catch (OverflowException)
                        {
                            Log.AddRuntimeLog(LID.ShowMessageWarning,
                                $"值类型转换溢�? {eType} -> {etype}, value={GetValueObject()}");
                            throw;
                        }
                    }
                    return;
                }
            }

            eType = etype;
            if (sobject == null)
            {
                SetNull();
                eType = etype;
                return;
            }

            object? raw = sobject.value;
            isNull = false;

            switch (etype)
            {
                case EVMType.Boolean:
                    {
                        if (sobject.eType == EVMType.Boolean)
                        {
                            uint8Value = (byte)(sobject.m_Numeric.u8 != 0 ? 1 : 0);
                        }
                        else
                        {
                            uint8Value = Convert.ToBoolean(raw, CultureInfo.InvariantCulture) ? (byte)1 : (byte)0;
                        }
                    }
                    break;
                case EVMType.UInt8:
                    {
                        if (sobject.eType == EVMType.UInt8)
                            uint8Value = sobject.m_Numeric.u8;
                        else
                            uint8Value = Convert.ToByte(raw, CultureInfo.InvariantCulture);
                    }
                    break;
                case EVMType.Int8:
                    {
                        if (sobject.eType == EVMType.Int8)
                            int8Value = sobject.m_Numeric.i8;
                        else
                            int8Value = Convert.ToSByte(raw, CultureInfo.InvariantCulture);
                    }
                    break;
                case EVMType.Num:
                    {
                        if (sobject != null && sobject.isNumeric)
                        {
                            float64Value = sobject.ToDouble();
                        }
                        else
                        {
                            float64Value = Convert.ToDouble(raw, CultureInfo.InvariantCulture);
                        }
                    }
                    break;
                case EVMType.Int16:
                    {
                        if (sobject.eType == EVMType.Int16)
                        {
                            int16Value = sobject.m_Numeric.i16;
                        }
                        else
                        {
                            int16Value = Convert.ToInt16(raw, CultureInfo.InvariantCulture);
                        }
                    }
                    break;
                case EVMType.UInt16:
                    {
                        if (sobject.eType == EVMType.UInt16)
                            uint16Value = sobject.m_Numeric.u16;
                        else
                            uint16Value = Convert.ToUInt16(raw, CultureInfo.InvariantCulture);
                    }
                    break;
                case EVMType.Int32:
                    {
                        if (sobject.eType == EVMType.Int32)
                            int32Value = sobject.m_Numeric.i32;
                        else
                            int32Value = Convert.ToInt32(raw, CultureInfo.InvariantCulture);
                    }
                    break;
                case EVMType.UInt32:
                    {
                        if (sobject.eType == EVMType.UInt32)
                            uint32Value = sobject.m_Numeric.u32;
                        else
                            uint32Value = Convert.ToUInt32(raw, CultureInfo.InvariantCulture);
                    }
                    break;
                case EVMType.Int64:
                    {
                        if (sobject.eType == EVMType.Int64)
                            int64Value = sobject.m_Numeric.i64;
                        else
                            int64Value = Convert.ToInt64(raw, CultureInfo.InvariantCulture);
                    }
                    break;
                case EVMType.UInt64:
                    {
                        if (sobject.eType == EVMType.UInt64)
                            uint64Value = sobject.m_Numeric.u64;
                        else
                            uint64Value = Convert.ToUInt64(raw, CultureInfo.InvariantCulture);
                    }
                    break;
                case EVMType.Float32:
                    {
                        if (sobject.eType == EVMType.Float32)
                            float32Value = sobject.m_Numeric.f32;
                        else
                            float32Value = Convert.ToSingle(raw, CultureInfo.InvariantCulture);
                    }
                    break;
                case EVMType.Float64:
                    {
                        if (sobject.eType == EVMType.Float64 || sobject.eType == EVMType.Num)
                            float64Value = sobject.m_Numeric.f64;
                        else
                            float64Value = Convert.ToDouble(raw, CultureInfo.InvariantCulture);
                    }
                    break;
                case EVMType.String:
                    {
                        if (sobject is StringObject so)
                        {
                            stringValue = so.value;
                        }
                        else
                        {
                            stringValue = raw?.ToString() ?? string.Empty;
                        }
                    }
                    break;
                case EVMType.Array:
                case EVMType.Type:
                case EVMType.Object:
                case EVMType.Class:
                    // 引用类型保持 sobject 引用，具体约束由上层类型系统处理�?
                    //Log.AddRuntimeLog(LID.ShowMessageAssert, "");
                    break;
            }
        }
        public Object GetValueObject()
        {
            switch (this.eType)
            {
                case EVMType.Boolean:
                    {
                        return uint8Value == 1;
                    }
                case EVMType.UInt8:
                    {
                        return uint8Value;
                    }
                case EVMType.Int8:
                    {
                        return int8Value;
                    }
                //case EVMType.Char:
                //    {
                //        return charValue;
                //    }
                case EVMType.Int16:
                    {
                        return int16Value;
                    }
                case EVMType.UInt16:
                    {
                        return uint16Value;
                    }
                case EVMType.Int32:
                    {
                        return int32Value;
                    }
                case EVMType.UInt32:
                    {
                        return uint32Value;
                    }
                case EVMType.Int64:
                    {
                        return int64Value;
                    }
                case EVMType.UInt64:
                    //case EVMType.RawUInt64:
                    {
                        return uint64Value;
                    }
                case EVMType.Float32:
                    {
                        return float32Value;
                    }
                case EVMType.Float64:
                    {
                        return float64Value;
                    }
                case EVMType.Num:
                    {
                        return float64Value;
                    }
                case EVMType.String:
                    {
                        return stringValue;
                    }
                default: return sobject;
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("RuntimeValue{");
            sb.Append("Type=");
            sb.Append(eType);
            sb.Append(", IsNull=");
            sb.Append(isNull);

            if (!isNull)
            {
                sb.Append(", Value=");
                switch (eType)
                {
                    case EVMType.String:
                        sb.Append('"');
                        sb.Append(stringValue ?? string.Empty);
                        sb.Append('"');
                        break;
                    case EVMType.Array:
                    case EVMType.Object:
                    case EVMType.Class:
                    case EVMType.Type:
                    case EVMType.Member:
                        if (sobject != null)
                        {
                            sb.Append(sobject.ToString());
                            sb.Append(", ObjectId=");
                            sb.Append(sobject.hashCode);
                        }
                        else
                        {
                            sb.Append("null");
                        }
                        break;
                    default:
                        sb.Append(Convert.ToString(GetValueObject(), CultureInfo.InvariantCulture));
                        break;
                }
            }

            sb.Append('}');

            return sb.ToString();
        }
    }
}
