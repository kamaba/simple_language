//****************************************************************************
//  File:      RuntimeValue.cs
// ------------------------------------------------
//  Copyright (c) kamaba233@gmail.com
//  DateTime: 2022/11/22 12:00:00
//  Description:  compute left and right value's method example: +-*/%&|^>><<
//****************************************************************************

using SimpleLanguage.Logging;
using SimpleLanguage.VM.Runtime;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace SimpleLanguage.VM
{
    public partial class RuntimeValueMethod
    {
        /// <summary>True if the value is a null reference or the VM <see cref="EVMType.Null"/> token.</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static bool IsNullLikeForArithmetic(ref RuntimeValue v)
        {
            if (v.isNull || v.eType == EVMType.Null) return true;
            if (v.eType == EVMType.Object || v.eType == EVMType.Class) return v.sobject == null;
            return false;
        }

        /// <summary>Primitive / Num not carrying null; excludes null-like references.</summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static bool IsStrictNumericNotNullLike(ref RuntimeValue v)
        {
            if (v.isNull || v.eType == EVMType.Null) return false;
            return IsNumericType(v.eType) || v.eType == EVMType.Num;
        }

        /// <summary>Maps <see cref="sign"/> in <see cref="ComputeValueInline"/> to a log display symbol.</summary>
        private static string SignToOperatorForLog(int sign) =>
            sign switch
            {
                0 => "+",
                1 => "-",
                2 => "*",
                3 => "/",
                4 => "%",
                5 => "&",
                6 => "|",
                7 => "^",
                8 => "<<",
                9 => ">>",
                _ => "?"
            };

        /// <summary>Logs and marks result null if one operand is null-like and the other is numeric (e.g. null + 3, 3 + null).</summary>
        private static bool HandleNullMixedWithNumericOperand(ref RuntimeValue left, ref RuntimeValue right, int sign)
        {
            bool lNull = IsNullLikeForArithmetic(ref left);
            bool rNull = IsNullLikeForArithmetic(ref right);
            if (!lNull && !rNull) return false;
            bool lNum = IsStrictNumericNotNullLike(ref left);
            bool rNum = IsStrictNumericNotNullLike(ref right);
            if ((lNull && rNum) || (rNull && lNum))
            {
                var op = SignToOperatorForLog(sign);
                var nullSide = lNull && rNum ? "宸︽搷浣滄暟" : "鍙虫搷浣滄暟";
                // 锟?ComputeValueInline 鍐呯洿鎺ヨ VM 鏃ュ織锛屼笉渚濊禆寮傚父閾捐矾锟?
                Log.AddRuntimeLog(LID.VMOperatorNotShouldHaveNull, string.Empty, op, nullSide);
                left.SetNull();
                return true;
            }
            return false;
        }

        // sign 0:+ 1:- 2:* 3:/ 4:% 5:& 6:| 7:^  8:<< 9:>>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ComputeValueInline(ref RuntimeValue left, int sign, ref RuntimeValue right, bool isUnSign)
        {
            RuntimeValue leftPrim = left;
            RuntimeValue rightPrim = right;
            leftPrim.TryNormalizeObjectScalarInPlace();
            rightPrim.TryNormalizeObjectScalarInPlace();

            if (sign == 0)
            {
                bool leftIsString = leftPrim.eType == EVMType.String;
                bool rightIsString = rightPrim.eType == EVMType.String;
                if (leftIsString || rightIsString)
                {
                    string ls;
                    string rs;
                    if (leftIsString)
                    {
                        ls = leftPrim.stringValue ?? string.Empty;
                    }
                    else
                    {
                        var obj = left.GetValueObject();
                        ls = obj != null ? obj.ToString() : string.Empty;
                    }

                    if (rightIsString)
                    {
                        rs = rightPrim.stringValue ?? string.Empty;
                    }
                    else
                    {
                        var obj = right.GetValueObject();
                        rs = obj != null ? obj.ToString() : string.Empty;
                    }

                    left.SetStringValue(ls + rs);
                    return;
                }
            }

            // Reject null / null-like reference mixed with a numeric operand for arithmetic
            // (avoid treating null as 0 锟?e.g. null + 5 and 5 + null must error).
            if (HandleNullMixedWithNumericOperand(ref leftPrim, ref rightPrim, sign))
            {
                left = leftPrim;
                return;
            }

            // If either side is a class-wrapped numeric SObject, prefer SObject operation methods
            bool leftIsNumObj = (left.eType == EVMType.Class || left.eType == EVMType.Object) && left.sobject != null && left.sobject.isNumeric;
            bool rightIsNumObj = (right.eType == EVMType.Class || right.eType == EVMType.Object) && right.sobject != null && right.sobject.isNumeric;
            if (leftIsNumObj || rightIsNumObj)
            {
                SObject leftNum = leftIsNumObj ? left.sobject : null;
                SObject rightNum = rightIsNumObj ? right.sobject : null;
                // left is numeric SObject -> perform operation on it
                if (leftNum != null)
                {
                    if (rightNum == null)
                    {
                        // wrap primitive right into a temporary SObject
                        var tmp = new SObject(EVMType.Float64);
                        switch (rightPrim.eType)
                        {
                            case EVMType.Float64: tmp.SetValue(rightPrim.float64Value); break;
                            case EVMType.Float32: tmp.SetValue(rightPrim.float32Value); break;
                            case EVMType.Int64: tmp.SetValue(rightPrim.int64Value); break;
                            case EVMType.UInt64: tmp.SetValue(rightPrim.uint64Value); break;
                            case EVMType.Int32: tmp.SetValue(rightPrim.int32Value); break;
                            case EVMType.UInt32: tmp.SetValue(rightPrim.uint32Value); break;
                            case EVMType.Int16: tmp.SetValue(rightPrim.int16Value); break;
                            case EVMType.UInt16: tmp.SetValue(rightPrim.uint16Value); break;
                            case EVMType.UInt8: tmp.SetValue(rightPrim.uint8Value); break;
                            case EVMType.Int8: tmp.SetValue(rightPrim.int8Value); break;
                            default: tmp.SetValue(rightPrim.float64Value); break;
                        }
                        leftNum.Operate(sign, tmp, isUnSign);
                        return;
                    }
                    else
                    {
                        leftNum.Operate(sign, rightNum, isUnSign);
                        return;
                    }
                }

                // Special-case: string concatenation for '+' when either side is a string
                // Treat any other type as its string representation (ToString)
                

                // right is numeric SObject, left is primitive -> compute into left primitive
                if (rightNum != null)
                {
                    var tmpLeft = new SObject(EVMType.Float64);
                    switch (leftPrim.eType)
                    {
                        case EVMType.Float64: tmpLeft.SetValue(leftPrim.float64Value); break;
                        case EVMType.Float32: tmpLeft.SetValue(leftPrim.float32Value); break;
                        case EVMType.Int64: tmpLeft.SetValue(leftPrim.int64Value); break;
                        case EVMType.UInt64: tmpLeft.SetValue(leftPrim.uint64Value); break;
                        case EVMType.Int32: tmpLeft.SetValue(leftPrim.int32Value); break;
                        case EVMType.UInt32: tmpLeft.SetValue(leftPrim.uint32Value); break;
                        case EVMType.Int16: tmpLeft.SetValue(leftPrim.int16Value); break;
                        case EVMType.UInt16: tmpLeft.SetValue(leftPrim.uint16Value); break;
                        case EVMType.UInt8: tmpLeft.SetValue(leftPrim.uint8Value); break;
                        case EVMType.Int8: tmpLeft.SetValue(leftPrim.int8Value); break;
                        default: tmpLeft.SetValue(leftPrim.float64Value); break;
                    }
                    tmpLeft.Operate(sign, rightNum, isUnSign);
                    // write back as double into leftPrim
                    leftPrim.SetDoubleValue(tmpLeft.ToDouble());
                    left = leftPrim;
                    return;
                }
            }

            // try fast path with RawRuntimeValue for purely numeric types (treat Num as Float64 in raw path)
            bool leftNumericRaw = IsNumericType(leftPrim.eType) || leftPrim.eType == EVMType.Num;
            bool rightNumericRaw = IsNumericType(rightPrim.eType) || rightPrim.eType == EVMType.Num;
            if (leftNumericRaw && rightNumericRaw)
            {
                var rl = RawRuntimeValue.FromRuntimeValue(ref leftPrim);
                var rr = RawRuntimeValue.FromRuntimeValue(ref rightPrim);
                ComputeValueInlineRaw(ref rl, sign, ref rr, isUnSign);
                rl.ApplyToRuntimeValue(ref leftPrim);
                // write back to original left (if it was a class-wrapped numeric, unbox result to primitive)
                left = leftPrim;
                return;
            }
            // unify numeric operations with promotion rules
            // treat Num as float64 for promotion purposes
            bool leftIsFloat = (leftPrim.eType == EVMType.Float32 || leftPrim.eType == EVMType.Float64 || leftPrim.eType == EVMType.Num);
            bool rightIsFloat = (rightPrim.eType == EVMType.Float32 || rightPrim.eType == EVMType.Float64 || rightPrim.eType == EVMType.Num);

            // If any side is float -> use double precision
            if (leftIsFloat || rightIsFloat)
            {
                double a = (leftPrim.eType == EVMType.Float64 || leftPrim.eType == EVMType.Num) ? leftPrim.float64Value : (leftPrim.eType == EVMType.Float32 ? (double)leftPrim.float32Value : leftPrim.ConvertToDoubleFromIntTypes());
                double b = (rightPrim.eType == EVMType.Float64 || rightPrim.eType == EVMType.Num) ? rightPrim.float64Value : (rightPrim.eType == EVMType.Float32 ? (double)rightPrim.float32Value : rightPrim.ConvertToDoubleFromIntTypes());
                double r = 0;
                switch (sign)
                {
                    case 0: r = a + b; break;
                    case 1: r = a - b; break;
                    case 2: r = a * b; break;
                    case 3: r = (b == 0) ? 0 : a / b; break;
                    case 4: r = (b == 0) ? 0 : a % b; break;
                    default:
                        Debug.Write("Error 不支持浮点的位运算");
                        break;
                }
                if (leftPrim.eType == EVMType.Float64 || leftPrim.eType == EVMType.Num)
                    leftPrim.float64Value = r;
                else
                    leftPrim.float32Value = (float)r;
                left = leftPrim;
                return;
            }

            // integer operations - decide signed vs unsigned based on flag or operand types
            bool useUnsigned = isUnSign || left.IsUnsignedType(leftPrim.eType) || right.IsUnsignedType(rightPrim.eType);
            if (useUnsigned)
            {
                ulong a = RuntimeValueMethod.ConvertToULong(leftPrim);
                ulong b = RuntimeValueMethod.ConvertToULong(rightPrim);
                ulong r = 0;
                switch (sign)
                {
                    case 0: r = a + b; break;
                    case 1: r = a - b; break;
                    case 2: r = a * b; break;
                    case 3: r = (b == 0) ? 0UL : a / b; break;
                    case 4: r = (b == 0) ? 0UL : a % b; break;
                    case 5: r = a & b; break;
                    case 6: r = a | b; break;
                    case 7: r = a ^ b; break;
                    case 8: r = a << (int)b; break;
                    case 9: r = a >> (int)b; break;
                }
                // write back according to original left type
                leftPrim.AssignULongToType(r);
                left = leftPrim;
                return;
            }

            // signed integer
            long la = RuntimeValueMethod.ConvertToLong(leftPrim);
            long lb = RuntimeValueMethod.ConvertToLong(rightPrim);
            long lr = 0;
            switch (sign)
            {
                case 0: lr = la + lb; break;
                case 1: lr = la - lb; break;
                case 2: lr = la * lb; break;
                case 3: lr = (lb == 0) ? 0L : la / lb; break;
                case 4: lr = (lb == 0) ? 0L : la % lb; break;
                case 5: lr = la & lb; break;
                case 6: lr = la | lb; break;
                case 7: lr = la ^ lb; break;
                case 8: lr = la << (int)lb; break;
                case 9: lr = la >> (int)lb; break;
            }
            leftPrim.AssignLongToType(lr);
            left = leftPrim;
        }

        public static void ComputeSVAlue(ref RuntimeValue _rv, int sign, ref RuntimeValue rightValue, bool isUnSign)
        {
            ComputeValueInline(ref _rv, sign, ref rightValue, isUnSign);
        }

        // ── Checked context overflow detection ──
        // Only integer arithmetic (+, -, *, /, %) can overflow. Floats, bitwise,
        // and shift operations are not affected by checked context.

        /// <summary>
        /// Checks if an integer arithmetic operation would overflow in checked context.
        /// Only applies to +, -, *, /, % (sign 0-4). Returns false for non-integer
        /// types, non-arithmetic operations, or when no overflow would occur.
        /// </summary>
        public static bool WouldOverflowIntegerArithmetic(ref RuntimeValue left, int sign, ref RuntimeValue right, bool isUnSign)
        {
            if (sign < 0 || sign > 4) return false;

            RuntimeValue leftPrim = left;
            RuntimeValue rightPrim = right;
            leftPrim.TryNormalizeObjectScalarInPlace();
            rightPrim.TryNormalizeObjectScalarInPlace();

            // Only integer types can overflow (floats don't overflow in checked context)
            if (!IsIntegerType(leftPrim.eType) || !IsIntegerType(rightPrim.eType))
                return false;

            // Determine promotion type using the same logic as ComputeValueInlineRaw
            EVMType promoType = GetRawBinaryPromotionType(leftPrim.eType, rightPrim.eType, sign, isUnSign);
            bool promoUnsigned = IsRawUnsignedInt(promoType);

            try
            {
                checked
                {
                    if (promoUnsigned)
                    {
                        ulong a = RuntimeValueMethod.ConvertToULong(leftPrim);
                        ulong b = RuntimeValueMethod.ConvertToULong(rightPrim);
                        ulong r;
                        switch (sign)
                        {
                            case 0: r = a + b; break;
                            case 1: r = a - b; break;
                            case 2: r = a * b; break;
                            case 3: if (b == 0) return false; r = a / b; break;
                            case 4: if (b == 0) return false; r = a % b; break;
                            default: return false;
                        }
                        return !FitsInUnsignedType(r, promoType);
                    }
                    else
                    {
                        long a = RuntimeValueMethod.ConvertToLong(leftPrim);
                        long b = RuntimeValueMethod.ConvertToLong(rightPrim);
                        long r;
                        switch (sign)
                        {
                            case 0: r = a + b; break;
                            case 1: r = a - b; break;
                            case 2: r = a * b; break;
                            case 3: if (b == 0) return false; r = a / b; break;
                            case 4: if (b == 0) return false; r = a % b; break;
                            default: return false;
                        }
                        return !FitsInSignedType(r, promoType);
                    }
                }
            }
            catch (OverflowException)
            {
                return true;
            }
        }

        private static bool IsIntegerType(EVMType t)
        {
            return IsRawSignedInt(t) || IsRawUnsignedInt(t);
        }

        private static bool FitsInSignedType(long value, EVMType type)
        {
            switch (type)
            {
                case EVMType.Int8: return value >= sbyte.MinValue && value <= sbyte.MaxValue;
                case EVMType.Int16: return value >= short.MinValue && value <= short.MaxValue;
                case EVMType.Int32: return value >= int.MinValue && value <= int.MaxValue;
                case EVMType.Int64: return true;
                default: return true;
            }
        }

        private static bool FitsInUnsignedType(ulong value, EVMType type)
        {
            switch (type)
            {
                case EVMType.UInt8: return value <= byte.MaxValue;
                case EVMType.UInt16: return value <= ushort.MaxValue;
                case EVMType.UInt32: return value <= uint.MaxValue;
                case EVMType.UInt64: return true;
                default: return true;
            }
        }

        /// <summary>
        /// Integer values in <see cref="RawRuntimeValue"/> may occupy only the low bits of <c>u64</c> (e.g. Int32).
        /// The <see cref="RawRuntimeValue.Int64"/> getter reinterpret-casts the whole <c>u64</c> as long, which breaks
        /// negative Int32 (e.g. -16) and thus signed shifts. Use this for signed arithmetic / comparisons.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static long RawRuntimeValueIntegerBitsToSignedLong(ref RawRuntimeValue r)
        {
            switch (r.eType)
            {
                case EVMType.Int8: return r.Int8;
                case EVMType.Int16: return r.Int16;
                case EVMType.Int32: return r.Int32;
                case EVMType.Int64: return unchecked((long)r.UInt64);
                case EVMType.UInt8: return r.UInt8;
                case EVMType.UInt16: return r.UInt16;
                case EVMType.UInt32: return (long)(uint)r.UInt32;
                case EVMType.UInt64: return unchecked((long)r.UInt64);
                default:
                    return unchecked((long)r.UInt64);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ComputeValueInlineRaw(ref RawRuntimeValue left, int sign, ref RawRuntimeValue right, bool isUnSign)
        {
            var promoteType = GetRawBinaryPromotionType(left.eType, right.eType, sign, isUnSign);
            if (promoteType == EVMType.Float64 || promoteType == EVMType.Num)
            {
                double a = (left.eType == EVMType.Float64 || left.eType == EVMType.Num) ? left.Float64 : (left.eType == EVMType.Float32 ? left.Float32 : (double)RawRuntimeValueIntegerBitsToSignedLong(ref left));
                double b = (right.eType == EVMType.Float64 || right.eType == EVMType.Num) ? right.Float64 : (right.eType == EVMType.Float32 ? right.Float32 : (double)RawRuntimeValueIntegerBitsToSignedLong(ref right));
                double r = 0;
                switch (sign)
                {
                    case 0: r = a + b; break;
                    case 1: r = a - b; break;
                    case 2: r = a * b; break;
                    case 3: r = (b == 0) ? 0 : a / b; break;
                    case 4: r = (b == 0) ? 0 : a % b; break;
                    default:
                        Debug.Write("Error 不支持浮点的位运算");
                        break;
                }
                left.eType = EVMType.Float64;
                left.Float64 = r;
                return;
            }
            if (promoteType == EVMType.Float32)
            {
                float a = left.eType == EVMType.Float32
                    ? left.Float32
                    : (left.eType == EVMType.Float64 || left.eType == EVMType.Num ? (float)left.Float64 : (float)RawRuntimeValueIntegerBitsToSignedLong(ref left));
                float b = right.eType == EVMType.Float32
                    ? right.Float32
                    : (right.eType == EVMType.Float64 || right.eType == EVMType.Num ? (float)right.Float64 : (float)RawRuntimeValueIntegerBitsToSignedLong(ref right));
                float r = 0f;
                switch (sign)
                {
                    case 0: r = a + b; break;
                    case 1: r = a - b; break;
                    case 2: r = a * b; break;
                    case 3: r = (b == 0f) ? 0f : a / b; break;
                    case 4: r = (b == 0f) ? 0f : a % b; break;
                    default:
                        Debug.Write("Error 不支持浮点的位运算");
                        break;
                }
                left.eType = EVMType.Float32;
                left.Float32 = r;
                return;
            }

            bool useUnsigned = (promoteType == EVMType.UInt64 || promoteType == EVMType.UInt32 || promoteType == EVMType.UInt16 || promoteType == EVMType.UInt8);
            if (useUnsigned)
            {
                ulong a = left.UInt64;
                ulong b = right.UInt64;
                ulong r = 0;
                switch (sign)
                {
                    case 0: r = a + b; break;
                    case 1: r = a - b; break;
                    case 2: r = a * b; break;
                    case 3: r = (b == 0) ? 0UL : a / b; break;
                    case 4: r = (b == 0) ? 0UL : a % b; break;
                    case 5: r = a & b; break;
                    case 6: r = a | b; break;
                    case 7: r = a ^ b; break;
                    case 8: r = a << (int)b; break;
                    case 9: r = a >> (int)b; break;
                }
                left.eType = promoteType;
                switch (promoteType)
                {
                    case EVMType.UInt64: left.UInt64 = r; break;
                    case EVMType.UInt32: left.UInt32 = (uint)r; break;
                    case EVMType.UInt16: left.UInt16 = (ushort)r; break;
                    case EVMType.UInt8: left.UInt8 = (byte)r; break;
                    default: left.UInt64 = r; break;
                }
                return;
            }

            long la = RawRuntimeValueIntegerBitsToSignedLong(ref left);
            long lb = RawRuntimeValueIntegerBitsToSignedLong(ref right);
            long lr = 0;
            switch (sign)
            {
                case 0: lr = la + lb; break;
                case 1: lr = la - lb; break;
                case 2: lr = la * lb; break;
                case 3: lr = (lb == 0) ? 0L : la / lb; break;
                case 4: lr = (lb == 0) ? 0L : la % lb; break;
                case 5: lr = la & lb; break;
                case 6: lr = la | lb; break;
                case 7: lr = la ^ lb; break;
                case 8: lr = la << (int)lb; break;
                case 9: lr = la >> (int)lb; break;
            }
            left.eType = promoteType;
            switch (promoteType)
            {
                case EVMType.Int64: left.Int64 = lr; break;
                case EVMType.Int32: left.Int32 = (int)lr; break;
                case EVMType.Int16: left.Int16 = (short)lr; break;
                case EVMType.Int8: left.Int8 = (sbyte)lr; break;
                default: left.Int64 = lr; break;
            }
        }

        private static bool IsRawUnsignedInt(EVMType t)
        {
            return t == EVMType.UInt8 || t == EVMType.UInt16 || t == EVMType.UInt32 || t == EVMType.UInt64;
        }

        private static bool IsRawSignedInt(EVMType t)
        {
            return t == EVMType.Int8 || t == EVMType.Int16 || t == EVMType.Int32 || t == EVMType.Int64;
        }

        private static EVMType GetRawBinaryPromotionType(EVMType left, EVMType right, int sign, bool isUnSign)
        {
            // Mainstream numeric promotion (C-like/C#/JVM style with pragmatic VM fallback):
            // 1) float64/num dominates, 2) float32 dominates over ints,
            // 3) integer ops promote narrow ints to int32, then widen by signed/unsigned mix.
            bool leftF64 = left == EVMType.Float64 || left == EVMType.Num;
            bool rightF64 = right == EVMType.Float64 || right == EVMType.Num;
            if (leftF64 || rightF64) return EVMType.Float64;
            if (left == EVMType.Float32 || right == EVMType.Float32) return EVMType.Float32;

            bool lUnsigned = IsRawUnsignedInt(left);
            bool rUnsigned = IsRawUnsignedInt(right);
            bool lSigned = IsRawSignedInt(left);
            bool rSigned = IsRawSignedInt(right);

            if (isUnSign)
            {
                if (left == EVMType.UInt64 || right == EVMType.UInt64) return EVMType.UInt64;
                if (left == EVMType.UInt32 || right == EVMType.UInt32) return EVMType.UInt32;
                return EVMType.Int32;
            }

            // Bitwise/shift on mixed sign types: keep 64-bit safety.
            bool isBitOp = sign >= 5 && sign <= 9;
            if (isBitOp && lUnsigned && rUnsigned)
            {
                // For pure unsigned bit operations, keep minimal unsigned width
                // instead of forcing int32 widening.
                if (left == EVMType.UInt64 || right == EVMType.UInt64) return EVMType.UInt64;
                if (left == EVMType.UInt32 || right == EVMType.UInt32) return EVMType.UInt32;
                if (left == EVMType.UInt16 || right == EVMType.UInt16) return EVMType.UInt16;
                return EVMType.UInt8;
            }

            if (left == EVMType.UInt64 || right == EVMType.UInt64)
            {
                if (lSigned || rSigned || isBitOp) return EVMType.Int64;
                return EVMType.UInt64;
            }
            if (left == EVMType.Int64 || right == EVMType.Int64) return EVMType.Int64;

            if (left == EVMType.UInt32 || right == EVMType.UInt32)
            {
                if (left == EVMType.UInt32 && right == EVMType.UInt32) return EVMType.UInt32;
                // int32 + uint32 => int64 (same as C# numeric promotion)
                return EVMType.Int64;
            }

            // byte/sbyte/short/ushort/int32 -> int32
            return EVMType.Int32;
        }
        /*
        public static void AddSValue(ref RuntimeValue _rv, ref RuntimeValue sval, bool isUnsign, out bool isMethodCall)
        {
            isMethodCall = false;
            if (sval.eType == EVMType.String)
            {
                string str = "";
                if (_rv.eType == EVMType.Class)
                {
                    ClassObject co = _rv.sobject as ClassObject;
                    if (co != null)
                    {
                        var method = co.runtimeType.runtimeClass.GetNonStaticMethodIndexByName("toString", out int index);
                        if (method != null)
                        {
                            CLRVM.RunIRMethodByRuntimeType(co.runtimeType, method );
                            var clrvm = CLRVM.clrRuntimeStack.Peek();
                            RuntimeValue curval = clrvm.GetCurrentIndexValue(clrvm.valueIndex - 1);
                            str = curval.stringValue;
                        }
                    }
                    else
                    {
                        str = sval.sobject.ToString();
                    }
                }
                else
                {
                    str = sval.GetValueObject().ToString();
                }
                _rv.stringValue = _rv.GetValueObject().ToString() + str;
                _rv.eType = EVMType.String;
            }
            else if (_rv.eType == EVMType.String)
            {
                string str = "";
                if (sval.eType == EVMType.Class)
                {
                    ClassObject co = sval.sobject as ClassObject;
                    if (co != null)
                    {
                        var method = co.runtimeType.runtimeClass.GetNonStaticMethodIndexByName("toString", out int index);
                        if (method != null)
                        {
                            CLRVM.RunIRMethodByRuntimeType(co.runtimeType, method );
                            var clrvm = CLRVM.clrRuntimeStack.Peek();
                            RuntimeValue curval = clrvm.GetCurrentIndexValue(clrvm.valueIndex - 1);
                            str = curval.stringValue;
                            clrvm.SetValueIndex( clrvm.valueIndex-1 );
                        }
                    }
                    else
                    {
                        str = sval.sobject.ToString();
                    }
                }
                else
                {
                    str = sval.GetValueObject().ToString();
                }
                _rv.stringValue = _rv.GetValueObject().ToString() + str;
            }
            else if (_rv.eType == EVMType.Array)
            {
                // 澶勭悊array1 + array2
            }
            else
            {
                if (_rv.eType == EVMType.Class)
                {
                    ClassObject co = sval.sobject as ClassObject;
                    if (co != null)
                    {
                        var method = co.runtimeType.runtimeClass.GetOperatorMethodIndexByMethod("_add_", out int index);
                        if (method != null)
                        {
                            CLRVM.RunIRMethodByRuntimeType(co.runtimeType, method);
                            isMethodCall = true;
                        }
                    }
                }
                else
                {
                    ComputeSVAlue(ref _rv, 0, ref sval, isUnsign);
                }
            }
        }
        */
        public static void MinusSValue(ref RuntimeValue _rv, RuntimeValue sval, bool isUnsign)
        {
            ComputeSVAlue(ref _rv, 1, ref sval, isUnsign);
        }
        public static void MultiplySValue(ref RuntimeValue _rv, RuntimeValue sval, bool isUnsign)
        {
            ComputeSVAlue(ref _rv, 2, ref sval, isUnsign);
        }
        public static void DivSValue(ref RuntimeValue _rv, RuntimeValue sval, bool isUnsign)
        {
            ComputeSVAlue(ref _rv, 3, ref sval, isUnsign);
        }
        public static void ModuloSValue(ref RuntimeValue _rv, RuntimeValue sval, bool isUnsign)
        {
            ComputeSVAlue(ref _rv, 4, ref sval, isUnsign);
        }
        public static void CombineSValue(ref RuntimeValue _rv, RuntimeValue sval, bool isUnsign)
        {
            ComputeSVAlue(ref _rv, 5, ref sval, isUnsign);
        }
        public static void InclusiveOrSValue(ref RuntimeValue _rv, RuntimeValue sval, bool isUnsign)
        {
            ComputeSVAlue(ref _rv, 6, ref sval, isUnsign);
        }
        public static void XORSValue(ref RuntimeValue _rv, RuntimeValue sval, bool isUnsign)
        {
            ComputeSVAlue(ref _rv, 7, ref sval, isUnsign);
        }
        public static void ShrSValue(ref RuntimeValue _rv, RuntimeValue sval, bool isUnsign)
        {
            ComputeSVAlue(ref _rv, 9, ref sval, isUnsign);
        }
        public static void ShiSValue(ref RuntimeValue _rv, RuntimeValue sval, bool isUnsign)
        {
            ComputeSVAlue(ref _rv, 8, ref sval, isUnsign);
        }
        public static void NotSValue(ref RuntimeValue _rv)
        {
            switch (_rv.eType)
            {
                case EVMType.UInt8:
                    {
                        _rv.eType = EVMType.Boolean;
                        _rv.uint8Value = (_rv.int8Value == 0) ? (byte)1 : (byte)0;
                    }
                    break;
                case EVMType.Int8:
                    {
                        _rv.eType = EVMType.Boolean;
                        _rv.uint8Value = (_rv.int8Value == 0) ? (byte)1 : (byte)0;
                    }
                    break;
                case EVMType.Boolean:
                    {
                        _rv.uint8Value = (_rv.int8Value == 0) ? (byte)1 : (byte)0;
                    }
                    break;
                //case EVMType.Char:
                //    {
                //        _rv.eType = EVMType.Boolean;
                //        _rv.int8Value = (charValue == 0) ? (byte)1 : (byte)0;
                //    }
                //    break;
                case EVMType.Int16:
                    {
                        _rv.eType = EVMType.Boolean;
                        _rv.uint8Value = (_rv.int16Value == 0) ? (byte)1 : (byte)0;
                    }
                    break;
                case EVMType.UInt16:
                    {
                        _rv.eType = EVMType.Boolean;
                        _rv.uint8Value = (_rv.uint16Value == 0) ? (byte)1 : (byte)0;
                    }
                    break;
                case EVMType.Int32:
                    {
                        _rv.eType = EVMType.Boolean;
                        _rv.uint8Value = (_rv.int32Value == 0) ? (byte)1 : (byte)0;
                    }
                    break;
                case EVMType.UInt32:
                    {
                        _rv.eType = EVMType.Boolean;
                        _rv.uint8Value = (_rv.uint32Value == 0) ? (byte)1 : (byte)0;
                    }
                    break;
                case EVMType.Int64:
                    {
                        _rv.eType = EVMType.Boolean;
                        _rv.uint8Value = (_rv.int64Value == 0) ? (byte)1 : (byte)0;
                    }
                    break;
                case EVMType.UInt64:
                    {
                        _rv.eType = EVMType.Boolean;
                        _rv.uint8Value = (_rv.uint64Value == 0) ? (byte)1 : (byte)0;
                    }
                    break;
            }
        }
        public static void NegSValue(ref RuntimeValue _rv)
        {
            switch (_rv.eType)
            {
                case EVMType.UInt8:
                    {
                        _rv.eType = EVMType.Int32;
                        _rv.int32Value = -_rv.int8Value;
                    }
                    break;
                case EVMType.Int8:
                    {
                        // Keep runtime type stable for unary minus.
                        _rv.int8Value = unchecked((sbyte)(-_rv.int8Value));
                    }
                    break;
                //case EVMType.Char:
                //    {
                //        _rv.eType = EVMType.Int32;
                //        _rv.int32Value = -charValue;
                //    }
                //    break;
                case EVMType.Int16:
                    {
                        // Keep runtime type stable for unary minus.
                        _rv.int16Value = unchecked((short)(-_rv.int16Value));
                    }
                    break;
                case EVMType.UInt16:
                    {
                        _rv.eType = EVMType.Int32;
                        _rv.int32Value = (-_rv.uint16Value);
                    }
                    break;
                case EVMType.Int32:
                    {
                        // Keep runtime type stable for unary minus.
                        _rv.int32Value = unchecked(-_rv.int32Value);
                    }
                    break;
                case EVMType.UInt32:
                    {
                        _rv.eType = EVMType.Int64;
                        _rv.int64Value = -_rv.uint32Value;
                    }
                    break;
                case EVMType.Int64:
                    {
                        // Keep runtime type stable for unary minus.
                        _rv.int64Value = unchecked(-_rv.int64Value);
                    }
                    break;
                case EVMType.UInt64:
                    {
                        Debug.Write("Error -value 1");
                    }
                    break;
                case EVMType.Float32:
                    {
                        _rv.float32Value = -_rv.float32Value;
                    }
                    break;
                case EVMType.Float64:
                    {
                        _rv.float64Value = -_rv.float64Value;
                    }
                    break;
                case EVMType.Num:
                    {
                        // treat Num as double
                        _rv.float64Value = -_rv.float64Value;
                    }
                    break;
                case EVMType.Class:
                    {
                        // if wrapped numeric object, negate its value
                        if (_rv.sobject != null && _rv.sobject.isNumeric)
                        {
                            double val = _rv.sobject.ToDouble();
                            _rv.sobject.SetValue(-val);
                        }
                        else
                        {
                            Log.AddRuntimeLog(LID.ShowMessageError, "Error -value on non-numeric class");
                        }
                    }
                    break;
                default:
                    {
                        Log.AddRuntimeLog(LID.ShowMessageError, "Error -value 2");
                    }
                    break;
            }
        }
    }
}
