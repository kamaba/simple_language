
public interface Core.IEnumableInterface
{
}