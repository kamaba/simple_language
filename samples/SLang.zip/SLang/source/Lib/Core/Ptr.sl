
Core.Ptr<T>
{
    
}