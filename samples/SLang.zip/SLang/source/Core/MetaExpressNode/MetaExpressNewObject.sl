﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using SimpleLanguage.Compile;



namespace SimpleLanguage.Core
{
    public class MetaBraceAssignStatements
    {
        public MetaMemberVariable metaMemberVariable => m_MetaMemberVariable;
        public MetaMemberData metaMemberData => m_MetaMemberData;
        public MetaExpressNode expressNode => m_MetaExpress;

        private MetaMemberVariable m_MetaMemberVariable;
        private MetaMemberData m_MetaMemberData;
        private Token m_AssignToken;
        private MetaExpressNode m_MetaExpress;
        private MetaBlockStatements m_OwnerMetaBlockStatements;
        private string m_DefineName = "";

        public int opLevel
        {
            get
            {
                return m_MetaExpress.opLevel;
            }
        }
        FileMetaDefineVariableSyntax m_FileMetaDefineVariableSyntax;
        FileMetaOpAssignSyntax m_FileMetaOpAssignSyntax;
        public MetaBraceAssignStatements(MetaBlockStatements mbs, MetaType mt, FileMetaCallLink fmcl)
        {
            m_OwnerMetaBlockStatements = mbs;
            if (fmcl != null)
            {
                m_MetaExpress = new MetaCallLinkExpressNode(fmcl, mt.metaClass, mbs, null);
                AllowUseSettings auc = new AllowUseSettings();
                auc.useNotConst = false;
                auc.useNotStatic = false;
                m_MetaExpress.Parse(auc);
                m_MetaExpress.CalcReturnType();
            }
        }
        public MetaBraceAssignStatements(MetaBlockStatements mbs, MetaType mc, MetaExpressNode men)
        {
            m_OwnerMetaBlockStatements = mbs;
            m_MetaExpress = men;
        }
        public MetaBraceAssignStatements(MetaBlockStatements mbs, MetaExpressNode men, MetaMemberVariable mmv )
        {
            m_OwnerMetaBlockStatements = mbs;
            m_MetaExpress = men;
            this.m_MetaMemberVariable = mmv;
        }
        public MetaBraceAssignStatements(MetaBlockStatements mbs, MetaType mt, FileMetaOpAssignSyntax fmos)
        {
            m_FileMetaOpAssignSyntax = fmos;
            m_OwnerMetaBlockStatements = mbs;
            if (fmos != null)
            {
                m_AssignToken = fmos.assignToken;
                if (fmos.variableRef.isOnlyName)
                {
                    m_DefineName = fmos.variableRef.name;
                    if (mt.isDynamicClass)
                    {
                        m_MetaMemberVariable = new MetaMemberVariable(null, m_DefineName);
                    }
                    else if( mt.isDynamicData )
                    {
                        m_MetaMemberData = new MetaMemberData(mt.metaClass as MetaData, fmos );
                        m_MetaMemberData.SetOwnerBlockstatements(m_OwnerMetaBlockStatements);
                        m_MetaMemberData.ParseDefineMetaType();
                        m_MetaExpress = m_MetaMemberData.expressNode;
                        m_MetaMemberData.ParseMetaExpress();
                        m_MetaMemberData.ParseChildMemberData();
                    }
                    else
                    {
                        if( mt.isData )
                        {
                            m_MetaMemberData = (mt.metaClass as MetaData).GetMemberDataByName(m_DefineName);
                            if (m_MetaMemberData == null)
                            {
                                Debug.Write("Error 在类" + mt.metaClass?.allClassName + "函数: " + mbs?.ownerMetaFunction.name
                                    + " 没有找到: 类" + mt.metaClass?.allClassName + " 变量:" + m_DefineName);
                            }
                            m_MetaExpress = CreateExpressNodeInNewObjectStatements(m_MetaMemberData, m_OwnerMetaBlockStatements, m_FileMetaOpAssignSyntax?.express);
                        }
                        else if( mt.isEnum )
                        {
                            Debug.Write("-----------------------------------Enum-------------------------");
                        }
                        else
                        {
                            m_MetaMemberVariable = mt.metaClass.GetMetaMemberVariableByName(m_DefineName);
                            if (m_MetaMemberVariable == null)
                            {
                                Debug.Write("Error 在类" + mt.metaClass?.allClassName + "函数: " + mbs?.ownerMetaFunction.name
                                    + " 没有找到: 类" + mt.metaClass?.allClassName + " 变量:" + m_DefineName);
                            }
                            m_MetaExpress = CreateExpressNodeInNewObjectStatements(m_MetaMemberVariable, m_OwnerMetaBlockStatements, m_FileMetaOpAssignSyntax?.express);
                        }
                    }

                }
                else
                {
                    Debug.Write("Error 在类" + mbs.ownerMetaClass?.allClassName + "函数: " + mbs.ownerMetaFunction.name
                        + " 语句: " + fmos.variableRef.ToTokenString());
                }
            }
        }
        public MetaBraceAssignStatements(MetaBlockStatements mbs, MetaType mt, FileMetaDefineVariableSyntax fmdvs)
        {
            m_FileMetaDefineVariableSyntax = fmdvs;
            m_OwnerMetaBlockStatements = mbs;
            if (fmdvs != null)
            {
                m_AssignToken = fmdvs.assignToken;

                m_DefineName = m_FileMetaDefineVariableSyntax.name;

                var fmcd = m_FileMetaDefineVariableSyntax.fileMetaClassDefine;
                var getMC = ClassManager.instance.GetMetaClassAndRegisterExptendTemplateClassInstance(mbs.ownerMetaClass, fmcd);
                var mdt = new MetaType(getMC);
                m_MetaMemberVariable = new MetaMemberVariable(null, m_DefineName, mdt.metaClass);

                var fileExpress = m_FileMetaDefineVariableSyntax.express;
                m_MetaExpress = CreateExpressNodeInNewObjectStatements(m_MetaMemberVariable, m_OwnerMetaBlockStatements, fileExpress);

            }
        }

        public MetaClass GetRetMetaClass()
        {
            if (m_MetaMemberVariable != null)
            {
                return m_MetaMemberVariable.ownerMetaClass;
            }
            if (m_MetaExpress != null)
            {
                return m_MetaExpress.GetReturnMetaClass();
            }
            return null;
        }
        public void SetDefineName( string definaname )
        {
            this.m_DefineName = definaname;
        }
        public bool CalcReturnType()
        {
            if (m_MetaExpress != null)
            {
                m_MetaExpress.CalcReturnType();

                if (m_MetaMemberVariable != null)
                {
                    MetaClass retMetaClass = m_MetaMemberVariable.metaDefineType.metaClass;
                    MetaClass ownerMetaClass = m_MetaMemberVariable.ownerMetaClass;
                    //bool m_IsNeedCastStatements = false;

                    m_MetaMemberVariable.SetMetaDefineType(m_MetaExpress.GetReturnMetaDefineType());
                }
                else if( m_MetaMemberData != null )
                {
                    MetaClass retMetaClass = m_MetaMemberData.metaDefineType.metaClass;
                    MetaClass ownerMetaClass = m_MetaMemberData.ownerMetaClass;
                    //bool m_IsNeedCastStatements = false;

                    m_MetaMemberData.SetMetaDefineType(m_MetaExpress.GetReturnMetaDefineType());
                }
                //ExpressManager.CalcDefineClassType(ref retMetaClass, m_MetaExpress, ownerMetaClass,
                //    m_OwnerMetaBlockStatements?.ownerMetaFunction, m_MetaVariable.name, ref m_IsNeedCastStatements);
                //差一个验证类型
            }
            else
            {
                Debug.Write("使用{}赋值，表达式不允许为空!!");
            }
            return true;
        }
        // 创建NewObject 即 Class c = Class(){ var1 = 1; } 的方式使用 1即生成的表达式
        public MetaExpressNode CreateExpressNodeInNewObjectStatements(MetaVariable mv, MetaBlockStatements mbs, FileMetaBaseTerm fme)
        {
            if (fme == null)
            {
                Debug.Write("Error !!!!!!!!!!");
                return null;
            }

            FileMetaBaseTerm curFMBT = fme;
            if (fme.left == null && fme.right == null)
            {
                if (fme is FileMetaTermExpress)
                {
                    curFMBT = (fme as FileMetaTermExpress).root;
                }
            }

            MetaClass mc = mbs?.ownerMetaClass;
            MetaClass selfMC = mv?.metaDefineType?.metaClass;
            switch (curFMBT)
            {
                case FileMetaConstValueTerm constValueTerm:
                    {
                        MetaExpressNode men = new MetaConstExpressNode(constValueTerm);

                        return men;
                    }
                case FileMetaCallTerm callTerm:
                    {
                        MetaCallLinkExpressNode clen = new MetaCallLinkExpressNode(callTerm.callLink, mc, mbs, null);
                        AllowUseSettings auc = new AllowUseSettings();
                        auc.useNotConst = false;
                        auc.useNotStatic = false;
                        auc.callConstructFunction = true;
                        auc.callFunction = true;
                        clen.Parse(auc);

                        return clen;
                    }
                case FileMetaBraceTerm fmbt:
                    {
                        MetaType mt = new MetaType(CoreMetaClassManager.objectMetaClass);
                        MetaNewObjectExpressNode mnoe = new MetaNewObjectExpressNode(fmbt, mt, mc, mbs, mv);
                        return mnoe;
                    }
                case FileMetaBracketTerm fmbt:
                    {
                        if(mv is MetaMemberData )
                        {
                            MetaType mt = new MetaType(CoreMetaClassManager.arrayMetaClass);
                            MetaNewObjectExpressNode mnoe = new MetaNewObjectExpressNode(fmbt, mt.metaClass, mbs, mv );
                            return mnoe;
                        }
                        else
                        {
                            Debug.Write("Error 只有在data varname = {} 支持 { cha1 = [] } 的格式,其它的表达式中不支持");
                        }
                        break;
                    }
                default:
                    {
                        Debug.Write("Error 暂不支持该类型的在NewObject中的解析!!");
                    }
                    break;
            }
            return null;
        }
        public string ToFormatString()
        {
            StringBuilder sb = new StringBuilder();

            if (m_MetaMemberVariable != null)
            {
                sb.Append(m_MetaMemberVariable.name);
            }
            sb.Append(m_AssignToken?.lexeme.ToString());
            sb.Append(m_MetaExpress?.ToFormatString());

            return sb.ToString();
        }
    }
    public class MetaBraceOrBracketStatementsContent
    {
        public enum EStatementsContentType
        {
            None,
            ArrayValue,
            ClassValueAssign,
            DataValueAssign,
            DynamicClass,
            DynamicData,
        }
        public EStatementsContentType contentType => m_ContentType;
        public int count => m_AssignStatementsList.Count;
        public List<MetaBraceAssignStatements> assignStatementsList => m_AssignStatementsList;
        public MetaType defineMetaType => m_DefineMetaType;


        private List<MetaBraceAssignStatements> m_AssignStatementsList = new List<MetaBraceAssignStatements>();
        private FileMetaBraceTerm m_FileMetaBraceTerm = null;
        private FileMetaBracketTerm m_FileMetaBracketTerm = null;
        private MetaClass m_OwnerMetaClass = null;
        private MetaBlockStatements m_OwnerMetaBlockStatements = null;
        private MetaType m_DefineMetaType = null;
        private MetaVariable m_EqualMetaVariable = null;
        private MetaData m_NewMetaData = null;
        private MetaData m_NewTempMetaData = null;
        private EStatementsContentType m_ContentType = EStatementsContentType.None;

        public MetaBraceOrBracketStatementsContent( MetaBlockStatements mbs, MetaClass mc )
        {
            m_OwnerMetaBlockStatements = mbs;
            m_OwnerMetaClass = mc;
            m_DefineMetaType = new MetaType(CoreMetaClassManager.objectMetaClass);
        }

        public MetaBraceOrBracketStatementsContent(FileMetaBraceTerm fileMetaBraceTerm, MetaBlockStatements mbs, MetaClass mc)
        {
            m_FileMetaBraceTerm = fileMetaBraceTerm;
            m_OwnerMetaBlockStatements = mbs;
            m_OwnerMetaClass = mc;
            m_DefineMetaType = new MetaType(CoreMetaClassManager.objectMetaClass);
        }
        public MetaBraceOrBracketStatementsContent(FileMetaBraceTerm fileMetaBraceTerm, MetaBlockStatements mbs, MetaClass mc, MetaVariable parentMt )
        {
            m_FileMetaBraceTerm = fileMetaBraceTerm;
            m_OwnerMetaBlockStatements = mbs;
            m_OwnerMetaClass = mc;
            m_EqualMetaVariable = parentMt;
            m_DefineMetaType = new MetaType(CoreMetaClassManager.objectMetaClass);
        }
        public MetaBraceOrBracketStatementsContent( FileMetaBracketTerm fileMetaBracketTerm, MetaBlockStatements mbs, MetaClass mc, MetaVariable parentMt)
        {
            m_FileMetaBracketTerm = fileMetaBracketTerm;
            m_OwnerMetaBlockStatements = mbs;
            m_OwnerMetaClass = mc;
            m_EqualMetaVariable = parentMt;
        }
        public void SetMetaType( MetaType mt )
        {
            m_DefineMetaType = mt;
        }
        public void Parse()
        {
            if( m_FileMetaBracketTerm != null )
            {
                List<FileInputParamNode> list = new List<FileInputParamNode>();
                var splitList = m_FileMetaBracketTerm.SplitParamList();
                for (int i = 0; i < splitList.Count; i++)
                {
                    var fas = splitList[i];

                    CreateExpressParam cep = new CreateExpressParam();
                    cep.ownerMetaClass = m_OwnerMetaClass;
                    cep.ownerMBS = m_OwnerMetaBlockStatements;
                    cep.metaType = new MetaType(CoreMetaClassManager.int32MetaClass);
                    cep.fme = fas;
                    cep.equalMetaVariable = m_EqualMetaVariable;
                    MetaExpressNode men = ExpressManager.CreateExpressNode(cep);
                    MetaBraceAssignStatements mas = new MetaBraceAssignStatements(m_OwnerMetaBlockStatements, new MetaType(m_OwnerMetaClass), men);
                    mas.CalcReturnType();
                    m_AssignStatementsList.Add(mas);
                }
                m_ContentType = EStatementsContentType.ArrayValue;
            }

            if (m_FileMetaBraceTerm != null )
            {
                if( m_FileMetaBraceTerm.fileMetaCallLinkList?.Count > 0 )
                {
                    Debug.Write("-------------------------------------------------------------------");
                    for (int i = 0; i < m_FileMetaBraceTerm.fileMetaCallLinkList.Count; i++)
                    {
                        var fas = m_FileMetaBraceTerm.fileMetaCallLinkList[i];
                        MetaBraceAssignStatements mas = new MetaBraceAssignStatements(m_OwnerMetaBlockStatements, new MetaType(m_OwnerMetaClass), fas);
                        m_AssignStatementsList.Add(mas);
                        m_ContentType = EStatementsContentType.ClassValueAssign;
                    }
                }
                if( m_FileMetaBraceTerm.fileMetaAssignSyntaxList != null && m_FileMetaBraceTerm.fileMetaAssignSyntaxList.Count > 0 )
                {
                    if( m_DefineMetaType.isData )
                    {
                        if( m_DefineMetaType.isDynamicData )
                        {
                            string anname = "DynamicData_";
                            if (m_EqualMetaVariable != null)
                            {
                                anname = anname + m_EqualMetaVariable.name + "_";
                            }
                            if (m_FileMetaBraceTerm != null)
                            {
                                anname = anname + m_FileMetaBraceTerm.token?.path + "_" + m_FileMetaBraceTerm.token?.sourceBeginLine.ToString() + "_" + GetHashCode().ToString();
                            }

                            m_NewTempMetaData = new MetaData(anname, false, false, true );
                            if (m_EqualMetaVariable?.pingToken != null)
                            {
                                m_NewTempMetaData.AddPingToken(m_EqualMetaVariable.pingToken);
                            }
                            m_NewTempMetaData.AddPingToken(m_FileMetaBraceTerm.token);
                            m_DefineMetaType = new MetaType(m_NewTempMetaData);
                            for (int i = 0; i < m_FileMetaBraceTerm.fileMetaAssignSyntaxList.Count; i++)
                            {
                                var fas = m_FileMetaBraceTerm.fileMetaAssignSyntaxList[i];
                                var foas = fas as FileMetaOpAssignSyntax;
                                var fdvs = fas as FileMetaDefineVariableSyntax;
                                MetaBraceAssignStatements mas = null;
                                if (foas != null)
                                {
                                    foas.express.BuildAST();
                                    mas = new MetaBraceAssignStatements(m_OwnerMetaBlockStatements, m_DefineMetaType, foas);
                                }
                                else if (fdvs != null)
                                {
                                    //fdvs.express.BuildAST();
                                    //mas = new MetaBraceAssignStatements(m_OwnerMetaBlockStatements, m_DefineMetaType, fdvs);
                                    Debug.Write("Error 不允许的表达式类形在 a = { int a; } 这种的形式里边");
                                }
                                else
                                {
                                    Debug.Write("Error 不允许的表达式类形在 a = {} 这种的形式里边");
                                }
                                mas.CalcReturnType();
                                assignStatementsList.Add(mas);
                            }

                            for (int i = 0; i < assignStatementsList.Count; i++)
                            {
                                var mmv = assignStatementsList[i].metaMemberData;
                                m_NewTempMetaData.AddMetaMemberData(mmv);
                            }
                            MetaData retClass = ClassManager.instance.FindMetaData(m_NewTempMetaData);
                            if (retClass == null)
                            {
                                ClassManager.instance.AddMetaData(m_NewTempMetaData);
                                retClass = m_NewTempMetaData;
                            }
                            m_NewMetaData = retClass;
                            for (int i = 0; i < assignStatementsList.Count; i++)
                            {
                                var mmv = assignStatementsList[i].metaMemberData;
                                //mmv.metaDefineType.SetRawMetaClass(m_NewMetaData);
                                //mmv.metaDefineType.SetMetaClass(m_NewMetaData);
                            }
                            m_DefineMetaType.SetMetaClass(m_NewMetaData);
                            m_DefineMetaType.SetTemplateMetaClass(m_NewMetaData);
                            m_ContentType = EStatementsContentType.DynamicData;
                            m_EqualMetaVariable?.SetMetaDefineType(m_DefineMetaType);
                        }
                        else
                        {
                            for (int i = 0; i < m_FileMetaBraceTerm.fileMetaAssignSyntaxList.Count; i++)
                            {
                                var fas = m_FileMetaBraceTerm.fileMetaAssignSyntaxList[i];
                                var foas = fas as FileMetaOpAssignSyntax;
                                if (foas != null)
                                {
                                    foas.express.BuildAST();
                                    MetaBraceAssignStatements mas = new MetaBraceAssignStatements(m_OwnerMetaBlockStatements, m_DefineMetaType, foas);
                                    assignStatementsList.Add(mas);
                                }
                                else
                                {
                                    Debug.Write("Error 该处应该是使用赋值，不能有其它表达式!!" + fas.token?.ToLexemeAllString());
                                    continue;
                                }
                            }
                            m_ContentType = EStatementsContentType.DataValueAssign;
                        }
                    }
                    else
                    {
                        if( m_DefineMetaType.isDynamicClass )
                        {
                            //m_MetaDefineType.SetDynamicClass(true);  ??

                            MetaDynamicClass anonClass = new MetaDynamicClass("DynamicClass__" + GetHashCode());
                            //构建匿名类中的项
                            for (int i = 0; i < m_FileMetaBraceTerm.fileMetaAssignSyntaxList.Count; i++)
                            {
                                var fas = m_FileMetaBraceTerm.fileMetaAssignSyntaxList[i];
                                var foas = fas as FileMetaOpAssignSyntax;
                                var fdvs = fas as FileMetaDefineVariableSyntax;
                                MetaBraceAssignStatements mas = null;
                                if (foas != null)
                                {
                                    foas.express.BuildAST();
                                    mas = new MetaBraceAssignStatements(m_OwnerMetaBlockStatements, m_DefineMetaType, foas);
                                }
                                else if (fdvs != null)
                                {
                                    fdvs.express.BuildAST();
                                    mas = new MetaBraceAssignStatements(m_OwnerMetaBlockStatements, m_DefineMetaType, fdvs);
                                }
                                mas.CalcReturnType();
                                assignStatementsList.Add(mas);
                            }

                            for (int i = 0; i < assignStatementsList.Count; i++)
                            {
                                var mmv = assignStatementsList[i].metaMemberVariable;
                                anonClass.AddMetaMemberVariable(assignStatementsList[i].metaMemberVariable, false);
                            }
                            MetaClass retClass = ClassManager.instance.FindDynamicClass(anonClass);
                            if (retClass == null)
                            {
                                for (int i = 0; i < assignStatementsList.Count; i++)
                                {
                                    var mmv = assignStatementsList[i].metaMemberVariable;
                                    mmv.SetOwnerMetaClass(retClass);
                                }
                                ClassManager.instance.AddDynamicClass(anonClass);
                                retClass = anonClass;
                            }
                            else
                            {
                                var list = anonClass.allMetaMemberVariableList;
                                if (list.Count == assignStatementsList.Count)
                                {

                                }
                            }
                            m_DefineMetaType = new MetaType(retClass);
                            m_ContentType = EStatementsContentType.DynamicClass;
                        }
                        else
                        {
                            for (int i = 0; i < m_FileMetaBraceTerm.fileMetaAssignSyntaxList.Count; i++)
                            {
                                var fas = m_FileMetaBraceTerm.fileMetaAssignSyntaxList[i];
                                var foas = fas as FileMetaOpAssignSyntax;
                                if (foas != null)
                                {
                                    foas.express.BuildAST();
                                    MetaBraceAssignStatements mas = new MetaBraceAssignStatements(m_OwnerMetaBlockStatements, m_DefineMetaType, foas);
                                    assignStatementsList.Add(mas);
                                }
                                else
                                {
                                    Debug.Write("Error 该处应该是使用赋值，不能有其它表达式!!" + fas.token?.ToLexemeAllString());
                                    continue;
                                }
                            }
                            m_ContentType = EStatementsContentType.ClassValueAssign;
                        }
                    }
                }
            }
        }
        public MetaClass GetMaxLevelMetaClassType()
        {
            //这个函数要处理 [1,2,3] 相同情况的类型    [1, 2.3f, 3.0d] 相同数字的最大类型确定 
            // [1UL, 2.3f] 这种情况，刚都按object处理  [1,"123", 3.0f] 不相同时 结果是object
            MetaClass mc = CoreMetaClassManager.objectMetaClass;
#pragma warning disable CS0219 // 变量已被赋值，但从未使用过它的值
            bool isAllSame = true;
#pragma warning restore CS0219 // 变量已被赋值，但从未使用过它的值
            for (int i = 0; i < m_AssignStatementsList.Count - 1; i++)
            {
                MetaBraceAssignStatements cmc = m_AssignStatementsList[i];
                MetaBraceAssignStatements nmc = m_AssignStatementsList[i + 1];
                if (cmc.opLevel == nmc.opLevel)
                {
                    if (cmc.opLevel == 10)
                    {
                        var cur = cmc.GetRetMetaClass();
                        var next = nmc.GetRetMetaClass();
                        var relation = ClassManager.ValidateClassRelationByMetaClass(cur, next);
                        if (relation == ClassManager.EClassRelation.Same
                            || relation == ClassManager.EClassRelation.Child)
                        {
                            mc = next;
                        }
                        else if (relation == ClassManager.EClassRelation.Parent)
                        {
                            mc = cur;
                        }
                        else
                        {
                            isAllSame = false;
                            break;
                        }
                    }
                    else
                    {
                        mc = cmc.GetRetMetaClass();
                        isAllSame = true;
                    }

                }
                else
                {
                    if (cmc.opLevel > nmc.opLevel)
                    {
                        mc = cmc.GetRetMetaClass();
                    }
                    else
                    {
                        mc = nmc.GetRetMetaClass();
                    }
                }
            }
            return mc;
        }
        public string ToFormatString()
        {
            StringBuilder sb = new StringBuilder();

            if (m_AssignStatementsList.Count > 0)
            {
                sb.Append("{");
                for (int i = 0; i < m_AssignStatementsList.Count; i++)
                {
                    var mas = m_AssignStatementsList[i];

                    sb.Append(mas.ToFormatString());
                    if (i < m_AssignStatementsList.Count - 1)
                        sb.Append(", ");
                }
                sb.Append("}");
            }
            return sb.ToString();
        }
    }
    public sealed class MetaNewObjectExpressNode : MetaExpressNode
    {
        public enum ENewType
        {
            CommomClass,
            ArrayClass,
            ListClass,
            MapClass,
        }

        public List<MetaExpressNode> metaInputParamList => m_MetaInputParamList;
        public MetaMemberFunction metaMemberFunction => m_MetaMemberFunction;
        public MetaVariable storeMetaVariable => m_StoreMetaVariable;
        public MetaBraceOrBracketStatementsContent metaBraceOrBracketStatementsContent => m_MetaBraceOrBracketStatementsContent;

        private FileMetaParTerm m_FileMetaParTerm = null;
        private FileMetaCallTerm m_FileMetaCallTerm = null;
        private FileMetaConstValueTerm m_FileMetaConstValueTerm = null;

        private MetaExpressNode m_MetaEnumValue = null;
        private MetaBraceOrBracketStatementsContent m_MetaBraceOrBracketStatementsContent = null;
        private ENewType m_NewType = ENewType.CommomClass;


        protected MetaVariable m_StoreMetaVariable = null; //模板或者是调用时的函数        
        protected MetaMemberFunction m_MetaMemberFunction = null;
        protected List<MetaExpressNode> m_MetaInputParamList = new List<MetaExpressNode>();
        public MetaNewObjectExpressNode( MetaClass ownermc, List<MetaDynamicClass> list )
        {
            m_OwnerMetaClass = ownermc;
            m_OwnerMetaBlockStatements = null;
            m_MetaBraceOrBracketStatementsContent = null;;

            var metaInputTemplateCollection = new MetaInputTemplateCollection();
            //MetaType mitp = new MetaType(MetaDynamicClass);
            //metaInputTemplateCollection.AddMetaTemplateParamsList(mitp);
            m_MetaDefineType = new MetaType(CoreMetaClassManager.arrayMetaClass, null, metaInputTemplateCollection);

            //MetaInputParamCollection mipc = new MetaInputParamCollection(mc, mbs);
            //mipc.AddMetaInputParam(new MetaInputParam(new MetaConstExpressNode(EType.Int32, m_MetaBraceOrBracketStatementsContent.count)));
            //MetaMemberFunction mmf = m_MetaDefineType.metaClass.GetMetaMemberConstructFunction(mipc);

            //m_MetaConstructFunctionCall = new MetaMethodCall(m_MetaDefineType.metaClass, mmf, mipc);
        }
        // 1..x
        public MetaNewObjectExpressNode(FileMetaConstValueTerm arrayLinkToken, MetaClass ownerMC, MetaBlockStatements mbs )
        {
            m_FileMetaConstValueTerm = arrayLinkToken;
            m_OwnerMetaClass = ownerMC;
            m_OwnerMetaBlockStatements = mbs;

            var metaInputTemplateCollection = new MetaInputTemplateCollection();
            MetaType mitp = new MetaType(CoreMetaClassManager.int32MetaClass);
            metaInputTemplateCollection.AddMetaTemplateParamsList(mitp);

            m_MetaDefineType = new MetaType(CoreMetaClassManager.rangeMetaClass, null, metaInputTemplateCollection);

            MetaInputParamCollection mdpc = new MetaInputParamCollection( ownerMC, mbs );
            String[] arr = m_FileMetaConstValueTerm.name.Split("..");
            if (arr.Length == 2)
            {
                int arr0 = 0;
                if (int.TryParse(arr[0], out arr0))
                {
                    MetaConstExpressNode mcen1 = new MetaConstExpressNode(EType.Int32, arr0);
                    MetaInputParam mip = new MetaInputParam(mcen1);
                    mdpc.AddMetaInputParam(mip);
                }
                else
                {
                    //处理前边定义过的变量
                }

                int arr1 = 0;
                if (int.TryParse(arr[1], out arr1))
                {
                    MetaConstExpressNode mcen2 = new MetaConstExpressNode(EType.Int32, arr[1]);
                    MetaInputParam mip2 = new MetaInputParam(mcen2);
                    mdpc.AddMetaInputParam(mip2);
                }
                else
                {
                    //处理前边定义过的变量
                }

                MetaInputParam mip3 = new MetaInputParam(new MetaConstExpressNode(EType.Int32, 1 ));
                mdpc.AddMetaInputParam(mip3);
            }
            var tfunction = m_MetaDefineType.GetMetaMemberConstructFunction(mdpc);

            if(tfunction != null )
            {
                //m_MetaConstructFunctionCall = new MetaMethodCall(null, null, tfunction, null, mdpc, null, null);
            }

            Init();
        }
        //public MetaNewObjectExpressNode(FileMetaCallTerm fmct, MetaCallLink mcl, MetaType mt, MetaClass ownerMC, MetaBlockStatements mbs )
        //{
        //    m_OwnerMetaClass = ownerMC;
        //    m_OwnerMetaBlockStatements = mbs;
        //    m_MetaDefineType = new MetaType(mt);
        //    eType = EType.Array;
        //}
        public MetaNewObjectExpressNode( MetaType mt, MetaClass ownerMC, MetaBlockStatements mbs )
        {
            m_OwnerMetaClass = ownerMC;
            m_OwnerMetaBlockStatements = mbs;
            m_MetaDefineType = new MetaType(mt);
            Init();
            //m_MetaConstructFunctionCall = new MetaMethodCall(mt.metaClass, mt.defineTemplateMetaTypeList, m_OwnerMetaBlockStatements.ownerMetaFunction,
            //    null, null, null, null );
        }
        // Class1<Int32> a = Class1<Int32>( 10 ){ a = 20; } 
        // Enum1 e1 = Enum1.Val1( 20 );
        // c = Class1(){ a = 20, b = 20}  => 定义类
        public MetaNewObjectExpressNode(FileMetaCallTerm fmct, MetaCallLink mcl, MetaType mt, MetaClass ownerMC, MetaBlockStatements mbs, MetaMethodCall mmf )
        {
            m_FileMetaCallTerm = fmct;
            m_OwnerMetaClass = ownerMC;
            m_OwnerMetaBlockStatements = mbs;
            //m_MetaConstructFunctionCall = mmf;
            m_MetaDefineType = new MetaType( mt );
            var fmcn =  mcl.finalCallNode;

            bool needByFileMetaParTermSetTemplate = false;
            MetaInputTemplateCollection mitc = new MetaInputTemplateCollection();
            MetaClass createMC = null;
            if ( false )//!m_MetaDefineType.isDefineMetaClass) 此处需要检查是否使用定义的类型
            {
                if (fmcn.visitType == MetaVisitNode.EVisitType.New)
                {
                    m_MetaDefineType.SetMetaClass(fmcn.methodCall.function.ownerMetaClass);
                }
            }
            //if (fmcn.callNodeType == ECallNodeType.EnumDefaultValue)
            //{
            //    m_MetaDefineType.SetEnumValue(fmcn.GetMetaMemeberVariable());
            //}
            //else if (fmcn.callNodeType == ECallNodeType.EnumNewValue)
            //{
            //    m_MetaDefineType.SetEnumValue(fmcn.GetMetaMemeberVariable());
            //    m_MetaEnumValue = fmcn.metaExpressValue;
            //}
            else if (fmcn.visitType ==  MetaVisitNode.EVisitType.MethodCall )
            {
                createMC = mmf.function.ownerMetaClass;
                m_MetaDefineType.SetMetaClass(createMC);
                if (createMC.metaTemplateList.Count > 0)
                {
                    //if (fmcn.metaTemplateParamsCollection == null)
                    //{
                    //    needByFileMetaParTermSetTemplate = true;
                    //}
                }
            }

            ////if (fmcn != null && fmcn.methodCall?.instance != null)
            ////{
            ////    m_MetaBraceOrBracketStatementsContent = fmcn.metaBraceStatementsContent;
            ////}
            var list = fmct.callLink?.callNodeList;
            if (list != null && list.Count > 0)
            {
                var listfinalNode = list[list.Count - 1];
                FileMetaBraceTerm fmbt = listfinalNode.fileMetaBraceTerm;
                if (fmbt != null)
                {
                    //Debug.Write("Error 待测试!!!");
                    m_MetaBraceOrBracketStatementsContent = new MetaBraceOrBracketStatementsContent(fmbt, m_OwnerMetaBlockStatements, m_OwnerMetaClass );
                    m_MetaBraceOrBracketStatementsContent.SetMetaType(m_MetaDefineType);
                    m_MetaBraceOrBracketStatementsContent.Parse();
                    if (fmbt.isArray)
                    {
                        var metaInputTemplateCollection = new MetaInputTemplateCollection();
                        MetaClass mc = m_MetaBraceOrBracketStatementsContent.GetMaxLevelMetaClassType();
                        metaInputTemplateCollection.AddMetaTemplateParamsList(new MetaType(mc));

                        m_MetaDefineType.SetTemplateMetaClass(CoreMetaClassManager.arrayMetaClass);

                        //if (fmcn.metaTemplateParamsCollection == null)
                        //{
                        //    m_MetaDefineType.SetMetaInputTemplateCollection(metaInputTemplateCollection);
                        //}
                        //else
                        //{
                        //    m_MetaDefineType.SetMetaInputTemplateCollection(fmcn.metaTemplateParamsCollection);
                        //}
                        m_MetaDefineType.UpdateMetaClassByRawMetaClassAndInputTemplateCollection();
                    }
                }
                FileMetaParTerm fmpt = listfinalNode.fileMetaParTerm;
                if (fmpt != null)
                {
                    m_FileMetaParTerm = fmpt;
                    if (needByFileMetaParTermSetTemplate)
                    {
                        Debug.Write("Error 待测试!!!");
                        List<MetaClass> mtList = new List<MetaClass>();
                        MetaInputParamCollection mipc = new MetaInputParamCollection(m_FileMetaParTerm, ownerMC, mbs);
                        for (int i = 0; i < mipc.count; i++)
                        {
                            var mp = mipc.metaInputParamList[i];
                            mp.CaleReturnType();
                            mtList.Add(mp.GetRetMetaClass());
                        }
                        if (createMC == CoreMetaClassManager.rangeMetaClass)
                        {
                            bool isSame = true;
                            for (int i = 0; i < mtList.Count - 1; i++)
                            {
                                var curMc = mtList[i];
                                var nextMc = mtList[i + 1];
                                if (curMc != nextMc)
                                {
                                    isSame = false;
                                    break;
                                }
                            }
                            if (isSame)
                            {
                                m_MetaDefineType.AddDefineTemplateMetaType(new MetaType(mtList[0]));
                                m_MetaDefineType.AddGenTemplateMetaType(new MetaType(mtList[0]));
                            }
                        }
                    }
                    //MetaInputParam mip = new MetaInputParam(new MetaConstExpressNode(EType.Int16, assignStatementsList.Count));
                    //mipc.AddMetaInputParam(mip);
                }

            }
            Init();
        }
        // Class1 c = { a = 20, b = 20 };  => Class1 c = Class1(); c.a = 20; c.b = 20;
        // dynamic c = {a = 20, b = 20} => 动态类 
        // data c = {a = 20, b = 20} | c = {a = 20, b = 20} => 动态数据  
        // Map<int,string> map1 = new(10){ {1,"20"}, {2,"30}, {3,"50} }
        // List<int> list1 = new(){ 1,2,3,4,5 }
        public MetaNewObjectExpressNode( FileMetaBraceTerm fmbt, MetaType mt, MetaClass ownerMC, MetaBlockStatements mbs, MetaVariable equalMV )
        {
            m_MetaBraceOrBracketStatementsContent = new MetaBraceOrBracketStatementsContent(fmbt, mbs, ownerMC, equalMV );
            m_OwnerMetaClass = ownerMC;
            m_OwnerMetaBlockStatements = mbs;
            m_MetaDefineType = new MetaType(mt);
            m_MetaBraceOrBracketStatementsContent.SetMetaType(m_MetaDefineType);
            m_MetaBraceOrBracketStatementsContent.Parse();

            if (m_MetaBraceOrBracketStatementsContent.contentType == MetaBraceOrBracketStatementsContent.EStatementsContentType.DynamicClass)
            {
                m_MetaDefineType = m_MetaBraceOrBracketStatementsContent.defineMetaType;
            }
            if (m_MetaBraceOrBracketStatementsContent.contentType == MetaBraceOrBracketStatementsContent.EStatementsContentType.DynamicData )
            {
                m_MetaDefineType = m_MetaBraceOrBracketStatementsContent.defineMetaType;
            }
            else if( m_MetaBraceOrBracketStatementsContent.contentType == MetaBraceOrBracketStatementsContent.EStatementsContentType.ArrayValue )
            {
                var metaInputTemplateCollection = new MetaInputTemplateCollection();
                MetaClass mc = m_MetaBraceOrBracketStatementsContent.GetMaxLevelMetaClassType();
                metaInputTemplateCollection.AddMetaTemplateParamsList(new MetaType(mc));
                m_MetaDefineType = new MetaType(CoreMetaClassManager.arrayMetaClass, null, metaInputTemplateCollection);
            }
            Init();
        }
        // Class1 c = new( 1, 2 );  => Class1 c = Class1( 1, 2 );
        public MetaNewObjectExpressNode( FileMetaParTerm fmpt, MetaType mt, MetaClass mc, MetaBlockStatements mbs )
        {
            m_FileMetaParTerm = fmpt;
            m_OwnerMetaClass = mc;
            m_OwnerMetaBlockStatements = mbs;
            var mmf = new MetaMethodCall(null, null, mbs.ownerMetaFunction, null, null, null, null );
            //m_MetaConstructFunctionCall = mmf;
            m_MetaDefineType = new MetaType(mt);

            Init();
        }
        // Array arr = [1,2,3]
        public MetaNewObjectExpressNode( FileMetaBracketTerm fmbt, MetaClass mc, MetaBlockStatements mbs, MetaVariable equalMV )
        {
            m_OwnerMetaClass = mc;
            m_OwnerMetaBlockStatements = mbs;
            m_MetaBraceOrBracketStatementsContent = new MetaBraceOrBracketStatementsContent(fmbt, m_OwnerMetaBlockStatements, m_OwnerMetaClass, equalMV);

            m_MetaDefineType = new MetaType(CoreMetaClassManager.arrayMetaClass);
            m_NewType = ENewType.ArrayClass;
        }
        private void Init()
        {
            //if(m_MetaConstructFunctionCall != null )
            //{
            //    eType = m_MetaDefineType.metaClass.eType;
            //}
            //else
            //{
            //    if(m_MetaDefineType.isEnum )
            //    {
            //        eType = EType.Enum;
            //    }    
            //    else if( m_MetaDefineType.isData )
            //    {
            //        eType = EType.Data;
            //    }
            //    else
            //    {
            //        eType = EType.Class;
            //    }
            //}
        }
        public override void Parse(AllowUseSettings auc)
        {
            //该函数，进行，计算出， 要创建的类，使用的初始化函数，以及，初始化成员的解析

            if(m_NewType == ENewType.ArrayClass )
            {
                m_MetaBraceOrBracketStatementsContent.Parse();
                MetaClass inputType = m_MetaBraceOrBracketStatementsContent.GetMaxLevelMetaClassType();

                var metaInputTemplateCollection = new MetaInputTemplateCollection();
                MetaType mitp = new MetaType(inputType);
                metaInputTemplateCollection.AddMetaTemplateParamsList(mitp);

                MetaInputParamCollection mipc = new MetaInputParamCollection(m_OwnerMetaClass, m_OwnerMetaBlockStatements);
                mipc.AddMetaInputParam(new MetaInputParam(new MetaConstExpressNode(EType.Int32, m_MetaBraceOrBracketStatementsContent.count)));
                mipc.CaleReturnType();
                m_MetaMemberFunction = m_MetaDefineType.metaClass.GetMetaMemberConstructFunction(mipc);
                SetInputParams(mipc);
            }
        }
        void SetInputParams(MetaInputParamCollection _paramCollection)
        {
            if(m_MetaMemberFunction == null )
            {
                return;
            }
            int defineCount = m_MetaMemberFunction.metaMemberParamCollection.maxParamCount;
            List<MetaDefineParam> mpList = new();
            if (m_MetaMemberFunction.metaMemberParamCollection != null)
            {
                mpList = m_MetaMemberFunction.metaMemberParamCollection.metaDefineParamList;
            }

            int inputCount = _paramCollection != null ? _paramCollection.metaInputParamList.Count : 0;
            for (int i = 0; i < defineCount; i++)
            {
                if (i < inputCount)
                {
                    MetaInputParam mip = _paramCollection.metaInputParamList[i];
                    m_MetaInputParamList.Add(mip.express);
                }
                else
                {
                    MetaDefineParam mdp = mpList[i];
                    if (mdp != null)
                    {
                        m_MetaInputParamList.Add(mdp.expressNode);
                    }
                }
            }
        }
        public override int CalcParseLevel(int level)
        {
            //for (int i = 0; i < assignStatementsList.Count; i++)
            //{
            //    var mas = assignStatementsList[i];
            //    level = mas.CalcParseLevel(level);
            //}
            return level;
        }
        public override void CalcReturnType()
        {
            base.CalcReturnType();
            //for (int i = 0; i < assignStatementsList.Count; i++)
            //{
            //    assignStatementsList[i].CalcReturnType();
            //}
        }
        public override MetaType GetReturnMetaDefineType()
        {
            if(m_MetaDefineType != null )
            {
                return m_MetaDefineType;
            }
            //if (m_MetaConstructFunctionCall != null)
            //{
            //    m_MetaDefineType = m_MetaConstructFunctionCall.GeMetaDefineType();
            //}
            return m_MetaDefineType;
        }
        public override string ToTokenString()
        {
            return base.ToTokenString();
        }
        public override string ToFormatString()
        {
            StringBuilder sb = new StringBuilder();


            if( m_MetaDefineType.isEnum )
            {
                sb.Append(m_MetaDefineType.name );
                sb.Append(".");
                sb.Append(m_MetaDefineType.enumValue.name);
                if(m_MetaEnumValue != null)
                {
                    sb.Append("(");
                    sb.Append(m_MetaEnumValue.ToFormatString());
                    sb.Append(")");
                }
            }
            else if( m_MetaDefineType.isData )
            {
                sb.Append(m_MetaDefineType.name);
                sb.Append("{");
                if (m_MetaBraceOrBracketStatementsContent != null)
                {
                    for( int i = 0; i < m_MetaBraceOrBracketStatementsContent.count ; i++ )
                    {
                        var bsc = m_MetaBraceOrBracketStatementsContent.assignStatementsList[i];
                        if( bsc == null )
                        {
                            continue;
                        }
                        sb.Append(bsc.metaMemberData?.ToFormatString2(m_MetaDefineType.isDynamicData));

                        if( i < m_MetaBraceOrBracketStatementsContent.count - 1 )
                        {
                            sb.Append(",");
                        }
                    }
                }
                sb.Append("}");
            }
            else
            {
                if ( m_MetaDefineType != null )
                {
                    sb.Append(m_MetaDefineType.name + "()");
                    sb.Append(".");
                }
                //if(m_MetaConstructFunctionCall.m_CallerMetaVariable != null )
                //{
                //    sb.Append(m_MetaConstructFunctionCall.m_CallerMetaVariable.name);
                //    sb.Append(".");
                //    sb.Append(m_MetaConstructFunctionCall.function.name);
                //    sb.Append("(");
                //    if( m_MetaConstructFunctionCall.metaInputParamCollection != null )
                //    {
                //        int count = m_MetaConstructFunctionCall.metaInputParamCollection.metaInputParamList.Count;
                //        for ( int i = 0; i < count; i++ )
                //        {
                //            var mp = m_MetaConstructFunctionCall.metaInputParamCollection.metaInputParamList[i];
                //            sb.Append(mp.ToFormatString());
                //            if( i < count - 1 )
                //            {
                //                sb.Append(",");
                //            }
                //        }
                //    }
                //    sb.Append(")");
                //}
                sb.Append(m_MetaBraceOrBracketStatementsContent?.ToFormatString());
            }

            return sb.ToString();
        }
        /// <summary>
        ///  Class2 c = new( 1, 2 );
        /// </summary>
        /// <param name="root"></param>
        /// <param name="mc"></param>
        /// <param name="mbs"></param>
        /// <param name="selfMc"></param>
        /// <returns></returns>
        public static MetaNewObjectExpressNode CreateNewObjectExpressNodeByPar(FileMetaParTerm root, MetaType mt, MetaClass omc, MetaBlockStatements mbs)
        {
            var fmct = (root as FileMetaParTerm);
            if (fmct == null) return null;
            if (mt == null) return null;

            MetaInputParamCollection mpc = new MetaInputParamCollection(root, omc, mbs);

            if( mpc.metaInputParamList.Count > 0 )
            {
                MetaMemberFunction mmf = mt.GetMetaMemberConstructFunction(mpc);

                if (mmf == null) return null;

              
                MetaNewObjectExpressNode mnoen = new MetaNewObjectExpressNode(root, mt, omc, mbs );

                return mnoen;

            }
            else
            {
                MetaNewObjectExpressNode mnoen = new MetaNewObjectExpressNode( root, mt, omc, mbs );

                return mnoen;
            }
        }
    }
}
