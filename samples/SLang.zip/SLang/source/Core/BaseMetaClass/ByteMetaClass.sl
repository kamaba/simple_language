﻿//****************************************************************************
//  File:      ByteMetaClass.cs
// ------------------------------------------------
//  Copyright (c) kamaba233@gmail.com
//  DateTime: 2022/6/12 12:00:00
//  Description: 
//****************************************************************************
using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleLanguage.Core
{
    public class ByteMetaClass : MetaClass
    {
        public ByteMetaClass() : base(DefaultObject.Byte.ToString())
        {
            SetExtendClass(CoreMetaClassManager.objectMetaClass);
            m_Type = EType.Byte;
            m_ClassDefineType = EClassDefineType.InnerDefine;
        }
        public static MetaClass CreateMetaClass()
        {
            MetaClass mc = new ByteMetaClass();
            return mc;
        }
    }
    public class SByteMetaClass : MetaClass
    {
        public SByteMetaClass() : base(DefaultObject.SByte.ToString())
        {
            SetExtendClass(CoreMetaClassManager.objectMetaClass);
            m_Type = EType.SByte;
            m_ClassDefineType = EClassDefineType.InnerDefine;
        }
        public static MetaClass CreateMetaClass()
        {
            MetaClass mc = new SByteMetaClass();
            return mc;
        }
    }
}
