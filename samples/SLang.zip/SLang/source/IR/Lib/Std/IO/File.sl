﻿//****************************************************************************
//  File:      Console.cs
// ------------------------------------------------
//  Copyright (c) kamaba233@gmail.com
//  DateTime: 2025/11/13 12:00:00
//  Description: 
//****************************************************************************


namespace SimpleLanguage.Lib
{
    public static class File
    {
        public static bool Exists( string path )
        {
            return false;
        }
    }
}
